var structT__RL__API__SENS__CHIRP__PROF__COMN__CFG =
[
    [ "c_ChirpRxHpfSel", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#af41ae09a79cd8d6dc85e4be339048298", null ],
    [ "c_ChirpTxMimoPatSel", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#a2442fbe8da8b46e5510435739a0712c4", null ],
    [ "c_DfeFirSel", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#a31e5459f0d6112d934182aa2a599f84d", null ],
    [ "c_DigOutputBitsSel", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#a8aa63da2a4da6721272d525a560e25c7", null ],
    [ "c_DigOutputSampRate", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#a31d03e8b43e69be0977b9bd9c791c5f8", null ],
    [ "c_HpfFastInitDuration", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#ad3007bacc0780a40a19641ccf7682120", null ],
    [ "c_MiscSettings", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#ace809afb70e3701f8bed0956b285e525", null ],
    [ "c_Reserved", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#a8cb7e44eb1c3f29be371c2ab8ab20d6b", null ],
    [ "c_Reserved2", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#ae97986dd21021eefda9a6306bb86d4eb", null ],
    [ "c_VcoMultiChipMode", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#a85b7034eb46d5cf3f3d9e77a38bd396d", null ],
    [ "h_ChirpRampEndTime", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#ad68c076101aafc497a14cc5099ce1d67", null ],
    [ "h_CrdNSlopeMag", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#a560451e5e4528fa2358923810d2fd91f", null ],
    [ "h_NumOfAdcSamples", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#aa3e579d69c96714e88de29251fd0382c", null ],
    [ "w_Reserved", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#a00304c4cc3ce162fa44d4aedbfc55a3e", null ],
    [ "w_Reserved3", "structT__RL__API__SENS__CHIRP__PROF__COMN__CFG.html#a074c02f858e848a86c9b2b230708cdf4", null ]
];