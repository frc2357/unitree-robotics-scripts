var unionU__FECCTRL__FECSS__ERRAGG__STATUS1 =
[
    [ "b32_Reg", "unionU__FECCTRL__FECSS__ERRAGG__STATUS1.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b32_Set", "unionU__FECCTRL__FECSS__ERRAGG__STATUS1.html#a0b5a60163c4afb9ef15c0719dd4ba2f0", null ],
    [ "bits", "unionU__FECCTRL__FECSS__ERRAGG__STATUS1.html#aa853bfaa471a5327bc7c5947d5e5e7b0", null ]
];