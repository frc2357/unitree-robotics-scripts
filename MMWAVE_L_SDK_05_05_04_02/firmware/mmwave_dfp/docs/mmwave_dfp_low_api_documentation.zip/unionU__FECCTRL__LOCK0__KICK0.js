var unionU__FECCTRL__LOCK0__KICK0 =
[
    [ "b32_Reg", "unionU__FECCTRL__LOCK0__KICK0.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b32_Value", "unionU__FECCTRL__LOCK0__KICK0.html#a455f75cc0afd22fcfd63f1be0339b02f", null ],
    [ "bits", "unionU__FECCTRL__LOCK0__KICK0.html#a20e66fe980bcbcc8c03eea7e1feeb28e", null ]
];