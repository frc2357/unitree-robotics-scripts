var structT__RL__API__FECSS__GPADC__MEAS__CMD =
[
    [ "w_ConfigVal", "structT__RL__API__FECSS__GPADC__MEAS__CMD.html#a175925ab0664a80584e37b8aa037326e", null ],
    [ "w_ParamVal", "structT__RL__API__FECSS__GPADC__MEAS__CMD.html#a2e1f3e8d2adf3b6628cf4c205cff2143", null ],
    [ "w_Reserved1", "structT__RL__API__FECSS__GPADC__MEAS__CMD.html#a94b7e367d00db535542e6e8c74eeb78a", null ],
    [ "w_Reserved2", "structT__RL__API__FECSS__GPADC__MEAS__CMD.html#adad85885669e932d55697b63bec2a941", null ]
];