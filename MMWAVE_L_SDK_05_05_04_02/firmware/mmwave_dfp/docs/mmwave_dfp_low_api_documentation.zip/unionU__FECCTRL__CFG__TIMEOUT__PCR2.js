var unionU__FECCTRL__CFG__TIMEOUT__PCR2 =
[
    [ "b32_Reg", "unionU__FECCTRL__CFG__TIMEOUT__PCR2.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b32_Timeout", "unionU__FECCTRL__CFG__TIMEOUT__PCR2.html#a80884091f0a1535fed125cf5b05c7042", null ],
    [ "bits", "unionU__FECCTRL__CFG__TIMEOUT__PCR2.html#a2967ce48430d184fee17bdb852219b7b", null ]
];