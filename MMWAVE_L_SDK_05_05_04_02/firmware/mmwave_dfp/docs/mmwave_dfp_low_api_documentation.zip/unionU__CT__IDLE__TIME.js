var unionU__CT__IDLE__TIME =
[
    [ "b16_IdleTime", "unionU__CT__IDLE__TIME.html#a3a4011da566c01cad9b0961ecda41dc0", null ],
    [ "b16_Padfield_0", "unionU__CT__IDLE__TIME.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b32_Reg", "unionU__CT__IDLE__TIME.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__IDLE__TIME.html#a6e9dfb4a7585be9ee82615b51ef245bc", null ]
];