var unionU__CT__PERCHIRP__FREQ__SLOPE__REP__CNT =
[
    [ "b16_Padfield_0", "unionU__CT__PERCHIRP__FREQ__SLOPE__REP__CNT.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b16_PerchirpFreqSlopeRepCnt", "unionU__CT__PERCHIRP__FREQ__SLOPE__REP__CNT.html#a6eb22ecfc119982c6776510a311b3290", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__FREQ__SLOPE__REP__CNT.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__FREQ__SLOPE__REP__CNT.html#a0f9e865cb73370c4d9df0060489c6319", null ]
];