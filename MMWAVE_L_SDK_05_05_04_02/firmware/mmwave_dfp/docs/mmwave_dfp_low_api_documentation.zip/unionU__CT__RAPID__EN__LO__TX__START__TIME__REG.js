var unionU__CT__RAPID__EN__LO__TX__START__TIME__REG =
[
    [ "b32_Reg", "unionU__CT__RAPID__EN__LO__TX__START__TIME__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_RapidEnLoTx1StartTime", "unionU__CT__RAPID__EN__LO__TX__START__TIME__REG.html#a52e6b24e29121a2989306ba1cf4ac156", null ],
    [ "b8_RapidEnLoTx2StartTime", "unionU__CT__RAPID__EN__LO__TX__START__TIME__REG.html#ad2207ec9b623ec3ba5b6c542307bfb65", null ],
    [ "b8_RapidEnLoTx3StartTime", "unionU__CT__RAPID__EN__LO__TX__START__TIME__REG.html#a79c52b4500384c8516b9ef1ecaf0904b", null ],
    [ "b8_RapidEnLoTx4StartTime", "unionU__CT__RAPID__EN__LO__TX__START__TIME__REG.html#a4844a3c26ed585f1f3a7bc9d318c670b", null ],
    [ "bits", "unionU__CT__RAPID__EN__LO__TX__START__TIME__REG.html#a5523a37fe60c5c05d9413015fb4ca612", null ]
];