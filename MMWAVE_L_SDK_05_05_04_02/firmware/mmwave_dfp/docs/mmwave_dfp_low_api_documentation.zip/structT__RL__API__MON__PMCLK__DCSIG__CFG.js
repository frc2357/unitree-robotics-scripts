var structT__RL__API__MON__PMCLK__DCSIG__CFG =
[
    [ "h_Reserved1", "structT__RL__API__MON__PMCLK__DCSIG__CFG.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "h_RfFreqStart", "structT__RL__API__MON__PMCLK__DCSIG__CFG.html#ad498a6e150cfdc2499d08e74bdd3b346", null ],
    [ "w_Reserved2", "structT__RL__API__MON__PMCLK__DCSIG__CFG.html#adad85885669e932d55697b63bec2a941", null ],
    [ "w_Reserved3", "structT__RL__API__MON__PMCLK__DCSIG__CFG.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ]
];