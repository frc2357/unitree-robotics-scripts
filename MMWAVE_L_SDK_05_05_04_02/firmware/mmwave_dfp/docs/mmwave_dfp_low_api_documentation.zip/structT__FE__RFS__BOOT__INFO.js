var structT__FE__RFS__BOOT__INFO =
[
    [ "c_FecBootCfg", "structT__FE__RFS__BOOT__INFO.html#ab45c65061896f9d059480c7e1b6a396a", null ],
    [ "c_PwrModeAndXtalType", "structT__FE__RFS__BOOT__INFO.html#aaa11476616953e59e2ca9bdf7e4a7874", null ],
    [ "c_Reserved1", "structT__FE__RFS__BOOT__INFO.html#ad96962542b1b0b9bbad845921adee9b0", null ],
    [ "c_RfsApiCtrl", "structT__FE__RFS__BOOT__INFO.html#a25b2f074968c7b683a808448c598850a", null ],
    [ "h_ClkFreq", "structT__FE__RFS__BOOT__INFO.html#a37cbf8058d8ea19300c561b018f11f01", null ],
    [ "h_Reserved2", "structT__FE__RFS__BOOT__INFO.html#af6916cc7db5fbc2060e7cfe6bf4c12a9", null ]
];