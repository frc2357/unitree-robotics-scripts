var unionU__CT__TX__EN__BPM__SETTINGS =
[
    [ "b24_Padfield_0", "unionU__CT__TX__EN__BPM__SETTINGS.html#a5eee3a45ed8ea134718d5c80b151fa5c", null ],
    [ "b32_Reg", "unionU__CT__TX__EN__BPM__SETTINGS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b4_TxBpm", "unionU__CT__TX__EN__BPM__SETTINGS.html#aa3225bfda0002b7fb888f2068718e76d", null ],
    [ "b4_TxEn", "unionU__CT__TX__EN__BPM__SETTINGS.html#a96327274c22534e14ba981f9b2315bb3", null ],
    [ "bits", "unionU__CT__TX__EN__BPM__SETTINGS.html#a7d99b042b247acd6d7f65e1c5de688ea", null ]
];