var structT__RL__API__MON__LIVE__GPADC__CTM__CFG =
[
    [ "c_GpadcInstrStartOffset", "structT__RL__API__MON__LIVE__GPADC__CTM__CFG.html#a0bc4f7064a1f5fcf0b85e7f81f4bb941", null ],
    [ "c_NumOfGpadcInstr", "structT__RL__API__MON__LIVE__GPADC__CTM__CFG.html#a7c96e67bee7654b62b862f434add37ea", null ],
    [ "h_Reserved1", "structT__RL__API__MON__LIVE__GPADC__CTM__CFG.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "w_Reserved2", "structT__RL__API__MON__LIVE__GPADC__CTM__CFG.html#adad85885669e932d55697b63bec2a941", null ]
];