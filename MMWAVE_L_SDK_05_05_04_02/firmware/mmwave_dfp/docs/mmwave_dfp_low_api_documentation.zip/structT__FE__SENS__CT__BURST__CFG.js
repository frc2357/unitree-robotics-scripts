var structT__FE__SENS__CT__BURST__CFG =
[
    [ "c_NumOfChirpsAccum", "structT__FE__SENS__CT__BURST__CFG.html#a3c690eb3c1310c77797f114dc453f1a8", null ],
    [ "c_Reserved", "structT__FE__SENS__CT__BURST__CFG.html#a8cb7e44eb1c3f29be371c2ab8ab20d6b", null ],
    [ "h_NumOfBurstsInFrame", "structT__FE__SENS__CT__BURST__CFG.html#ae1b73d30c2a75836599ca7904871862b", null ],
    [ "h_NumOfChirpsInBurst", "structT__FE__SENS__CT__BURST__CFG.html#adad4392c747157ff5e2429e6b25024a4", null ],
    [ "h_Reserved1", "structT__FE__SENS__CT__BURST__CFG.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "w_BurstPeriodicity", "structT__FE__SENS__CT__BURST__CFG.html#ab858477d26b86792c25b655f126345a4", null ]
];