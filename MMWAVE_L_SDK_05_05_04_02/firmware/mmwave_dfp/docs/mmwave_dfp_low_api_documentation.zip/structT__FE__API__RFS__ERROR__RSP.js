var structT__FE__API__RFS__ERROR__RSP =
[
    [ "h_CommandId", "structT__FE__API__RFS__ERROR__RSP.html#a05320bfb1863a0dbb64a975cc76c3c5f", null ],
    [ "h_Reserved0", "structT__FE__API__RFS__ERROR__RSP.html#a27b4109a09931c84b82e632d31a8ea37", null ],
    [ "w_Reserved", "structT__FE__API__RFS__ERROR__RSP.html#a96856985895564689000d85fbbc3df89", null ],
    [ "xw_CmdErrorCode", "structT__FE__API__RFS__ERROR__RSP.html#a16a1f075db284463febbacbc41a1a110", null ]
];