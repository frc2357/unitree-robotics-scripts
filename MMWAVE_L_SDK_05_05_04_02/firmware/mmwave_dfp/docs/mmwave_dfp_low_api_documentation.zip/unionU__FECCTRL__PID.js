var unionU__FECCTRL__PID =
[
    [ "b16_Msb16", "unionU__FECCTRL__PID.html#a0f67977921b80734c1c2ca14a0bf7eb4", null ],
    [ "b2_Custom", "unionU__FECCTRL__PID.html#a416af652a811c9b1e59c5bf8f1d42362", null ],
    [ "b32_Reg", "unionU__FECCTRL__PID.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b3_Major", "unionU__FECCTRL__PID.html#acb930b5d7e8fdcd3c9f89009fdfbc97e", null ],
    [ "b5_Misc", "unionU__FECCTRL__PID.html#a36952c19d7b1f9dc6b2312f6049cdb71", null ],
    [ "b6_Minor", "unionU__FECCTRL__PID.html#aa4959c90d2d53d435436efade40f349a", null ],
    [ "bits", "unionU__FECCTRL__PID.html#ac58562c62f61fc18fa2acf87b1e052bd", null ]
];