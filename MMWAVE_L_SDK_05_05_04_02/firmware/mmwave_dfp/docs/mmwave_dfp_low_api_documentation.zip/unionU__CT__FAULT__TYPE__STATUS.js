var unionU__CT__FAULT__TYPE__STATUS =
[
    [ "b1_FaultNs", "unionU__CT__FAULT__TYPE__STATUS.html#aabb3d362af0ed82734afc69321a8f7a3", null ],
    [ "b25_Padfield_0", "unionU__CT__FAULT__TYPE__STATUS.html#a4054dfe3480d2d26f1996b52e7c862e7", null ],
    [ "b32_Reg", "unionU__CT__FAULT__TYPE__STATUS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b6_FaultType", "unionU__CT__FAULT__TYPE__STATUS.html#a49db2aa896e67a3d581c00bd88ce05fa", null ],
    [ "bits", "unionU__CT__FAULT__TYPE__STATUS.html#a3b689a063d20e7f0c989dc151eb2d201", null ]
];