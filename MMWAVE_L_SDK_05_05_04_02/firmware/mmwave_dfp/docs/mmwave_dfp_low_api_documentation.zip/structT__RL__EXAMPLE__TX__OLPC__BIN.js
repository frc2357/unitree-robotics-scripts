var structT__RL__EXAMPLE__TX__OLPC__BIN =
[
    [ "c_BackOffMap", "structT__RL__EXAMPLE__TX__OLPC__BIN.html#abffddbb70edec5f2fbd19b9747aaee6e", null ],
    [ "h_TxCodes", "structT__RL__EXAMPLE__TX__OLPC__BIN.html#a57b63200f95d40e6698a5c124536da28", null ]
];