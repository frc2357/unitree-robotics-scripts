var unionU__FECCTRL__INTR__RAW__STATUS =
[
    [ "b1_AddrErr", "unionU__FECCTRL__INTR__RAW__STATUS.html#ad736c9c43444f32ff2a68a41bd68b356", null ],
    [ "b1_KickErr", "unionU__FECCTRL__INTR__RAW__STATUS.html#a95601b0d3ee987f8596c9f39cebcf4b8", null ],
    [ "b1_ProtErr", "unionU__FECCTRL__INTR__RAW__STATUS.html#a5c8ca582a34990ed48eefb2e9bb90090", null ],
    [ "b1_ProxyErr", "unionU__FECCTRL__INTR__RAW__STATUS.html#a01760b9ef2377c17046dd9fb3e8c3aae", null ],
    [ "b28_Padfield_0", "unionU__FECCTRL__INTR__RAW__STATUS.html#a695ce030f1b67b139d277466993c83a0", null ],
    [ "b32_Reg", "unionU__FECCTRL__INTR__RAW__STATUS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__FECCTRL__INTR__RAW__STATUS.html#a9c39d7d86a5098c1b6c07653de34462d", null ]
];