var structT__FE__SENS__CT__STATUS =
[
    [ "h_BurstCount", "structT__FE__SENS__CT__STATUS.html#a7f6f5d96c287303565157dc18d6876db", null ],
    [ "h_Reserved1", "structT__FE__SENS__CT__STATUS.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "w_BurstPeriodTimerVal", "structT__FE__SENS__CT__STATUS.html#a5d231bc49b4efac4b3645af059e6d6b9", null ],
    [ "w_ChirpCount", "structT__FE__SENS__CT__STATUS.html#aba32d00a23360642740a37aa3ed42c20", null ]
];