var unionU__FECCTRL__CFG__TIMEOUT__PCR1 =
[
    [ "b32_Reg", "unionU__FECCTRL__CFG__TIMEOUT__PCR1.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b32_Value", "unionU__FECCTRL__CFG__TIMEOUT__PCR1.html#a455f75cc0afd22fcfd63f1be0339b02f", null ],
    [ "bits", "unionU__FECCTRL__CFG__TIMEOUT__PCR1.html#abf976166392f0ee40be6e89fea8f505f", null ]
];