var structT__FE__FECSS__DATA =
[
    [ "c_ApllClkCtrl", "structT__FE__FECSS__DATA.html#acc857f9f6775cd90b4fe981da595d11b", null ],
    [ "c_DevClkCtrl", "structT__FE__FECSS__DATA.html#aac7958dffe4f23436147c347a5d1f35d", null ],
    [ "c_FtClkCtrl", "structT__FE__FECSS__DATA.html#a517e7aef3e6364e27c179942b0a4288f", null ],
    [ "c_Reserved1", "structT__FE__FECSS__DATA.html#ad96962542b1b0b9bbad845921adee9b0", null ],
    [ "h_Reserved2", "structT__FE__FECSS__DATA.html#af6916cc7db5fbc2060e7cfe6bf4c12a9", null ],
    [ "h_XtalClkFreq", "structT__FE__FECSS__DATA.html#a795227e1317467430a5b0c5f4ad77e01", null ]
];