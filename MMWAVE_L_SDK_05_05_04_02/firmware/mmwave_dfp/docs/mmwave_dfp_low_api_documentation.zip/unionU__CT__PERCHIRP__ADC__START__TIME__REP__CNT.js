var unionU__CT__PERCHIRP__ADC__START__TIME__REP__CNT =
[
    [ "b16_Padfield_0", "unionU__CT__PERCHIRP__ADC__START__TIME__REP__CNT.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b16_PerchirpAdcStartTimeRepCnt", "unionU__CT__PERCHIRP__ADC__START__TIME__REP__CNT.html#af0d784fe62f8598efc5d68aad553f658", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__ADC__START__TIME__REP__CNT.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__ADC__START__TIME__REP__CNT.html#a8054aecf79274b60936f8933805d55d9", null ]
];