var unionU__CT__RX__EN__SETTINGS =
[
    [ "b24_Padfield_0", "unionU__CT__RX__EN__SETTINGS.html#a5eee3a45ed8ea134718d5c80b151fa5c", null ],
    [ "b32_Reg", "unionU__CT__RX__EN__SETTINGS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_RxEn", "unionU__CT__RX__EN__SETTINGS.html#a01b6d2976eee8552f7d5857e42cfbd2b", null ],
    [ "bits", "unionU__CT__RX__EN__SETTINGS.html#ade80211451ebb85361b64f92beffc564", null ]
];