var structT__RL__API__MON__LIVE__GPADC__CTM__INSTR =
[
    [ "w_ConfigVal", "structT__RL__API__MON__LIVE__GPADC__CTM__INSTR.html#a4c38671db8e848394531165334ea7425", null ],
    [ "w_ParamVal", "structT__RL__API__MON__LIVE__GPADC__CTM__INSTR.html#acbff0c1d5cf1630bc5dc97cb3f6c04a5", null ]
];