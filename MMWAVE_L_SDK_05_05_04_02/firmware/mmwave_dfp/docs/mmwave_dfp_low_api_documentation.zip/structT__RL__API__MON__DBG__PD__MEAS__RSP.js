var structT__RL__API__MON__DBG__PD__MEAS__RSP =
[
    [ "c_PdMeasSts", "structT__RL__API__MON__DBG__PD__MEAS__RSP.html#a0067cacf47e6bef5d8e41eb20960255e", null ],
    [ "c_Reserved0", "structT__RL__API__MON__DBG__PD__MEAS__RSP.html#a6e359a94ca4b7990d84c829a1183205b", null ],
    [ "h_DeltaSum", "structT__RL__API__MON__DBG__PD__MEAS__RSP.html#a32f5d4c7ee119db67a2f0cac46e8ac52", null ],
    [ "h_Reserved1", "structT__RL__API__MON__DBG__PD__MEAS__RSP.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "w_Reserved2", "structT__RL__API__MON__DBG__PD__MEAS__RSP.html#adad85885669e932d55697b63bec2a941", null ],
    [ "w_SumRfOff", "structT__RL__API__MON__DBG__PD__MEAS__RSP.html#a3645563f7d601cc2096d73383ae9fb52", null ],
    [ "w_SumRfON", "structT__RL__API__MON__DBG__PD__MEAS__RSP.html#afaba9861a154b1d4de1f9f7bf6f1c429", null ],
    [ "w_VpdRmsSqr", "structT__RL__API__MON__DBG__PD__MEAS__RSP.html#a418036d892e1c77e80b450300f98fc4a", null ],
    [ "xh_PdPwrDb", "structT__RL__API__MON__DBG__PD__MEAS__RSP.html#a24213fd218253b95d9caa8c82e85410a", null ]
];