var unionU__CT__RAPID__EN__RF__RX__END__TIME__REG =
[
    [ "b32_Reg", "unionU__CT__RAPID__EN__RF__RX__END__TIME__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_RapidEnRfRx1EndTime", "unionU__CT__RAPID__EN__RF__RX__END__TIME__REG.html#aa41e247dbda9d7c8e66fcbbf682b1bc2", null ],
    [ "b8_RapidEnRfRx2EndTime", "unionU__CT__RAPID__EN__RF__RX__END__TIME__REG.html#a7715447443b4c3aab187890038150f98", null ],
    [ "b8_RapidEnRfRx3EndTime", "unionU__CT__RAPID__EN__RF__RX__END__TIME__REG.html#a368b055ae4daa727c23b9b07c82d4cd4", null ],
    [ "b8_RapidEnRfRx4EndTime", "unionU__CT__RAPID__EN__RF__RX__END__TIME__REG.html#ab6a4439197e832b1a3a47e0bbf539312", null ],
    [ "bits", "unionU__CT__RAPID__EN__RF__RX__END__TIME__REG.html#aa05c79a0398c04da080c5c61638b6e5d", null ]
];