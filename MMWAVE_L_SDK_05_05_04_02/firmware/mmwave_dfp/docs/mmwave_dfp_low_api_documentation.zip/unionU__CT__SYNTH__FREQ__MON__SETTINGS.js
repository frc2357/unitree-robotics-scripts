var unionU__CT__SYNTH__FREQ__MON__SETTINGS =
[
    [ "b12_SynthFreqMonResetSoccAccumTime", "unionU__CT__SYNTH__FREQ__MON__SETTINGS.html#a54d09636a1c099725d79785b4550fc9c", null ],
    [ "b12_SynthFreqMonStartTime", "unionU__CT__SYNTH__FREQ__MON__SETTINGS.html#abe164377d78ae69b92ab23d1a2366799", null ],
    [ "b1_SynthFreqMonEn", "unionU__CT__SYNTH__FREQ__MON__SETTINGS.html#a84329556f6fc40371244164b20cbbf42", null ],
    [ "b32_Reg", "unionU__CT__SYNTH__FREQ__MON__SETTINGS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b7_Padfield_0", "unionU__CT__SYNTH__FREQ__MON__SETTINGS.html#a6fb63ee60a4d6e27ce7600b7cd5eea0c", null ],
    [ "bits", "unionU__CT__SYNTH__FREQ__MON__SETTINGS.html#af4ec078e6fa926d22b55b8e95bcbc6cb", null ]
];