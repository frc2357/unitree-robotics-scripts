var unionU__CT__PERCHIRP__TX__START__TIME__REP__CNT =
[
    [ "b16_Padfield_0", "unionU__CT__PERCHIRP__TX__START__TIME__REP__CNT.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b16_PerchirpTxStartTimeRepCnt", "unionU__CT__PERCHIRP__TX__START__TIME__REP__CNT.html#ae7bc623947552dbd07382f7ad914b786", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__TX__START__TIME__REP__CNT.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__TX__START__TIME__REP__CNT.html#a7a0dfc98ea4fbe8053183c6eb837d7e2", null ]
];