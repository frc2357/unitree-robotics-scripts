var structT__FE__API__RFS__CHIRP__PROFILE__CMD =
[
    [ "c_ChirpRxHpfSel", "structT__FE__API__RFS__CHIRP__PROFILE__CMD.html#af41ae09a79cd8d6dc85e4be339048298", null ],
    [ "c_DigOutputSampRate", "structT__FE__API__RFS__CHIRP__PROFILE__CMD.html#a31d03e8b43e69be0977b9bd9c791c5f8", null ],
    [ "c_Reserved1", "structT__FE__API__RFS__CHIRP__PROFILE__CMD.html#ad96962542b1b0b9bbad845921adee9b0", null ],
    [ "c_VcoMultiChipMode", "structT__FE__API__RFS__CHIRP__PROFILE__CMD.html#a85b7034eb46d5cf3f3d9e77a38bd396d", null ],
    [ "w_Reserved3", "structT__FE__API__RFS__CHIRP__PROFILE__CMD.html#a6908d2fd03d9892be76c7380306b484f", null ]
];