var structT__RL__API__MON__LIVE__GAPDC__CTM__RESULT =
[
    [ "h_GpadcMax", "structT__RL__API__MON__LIVE__GAPDC__CTM__RESULT.html#a38c1c00091d1360bf6b0e1e3b590c72f", null ],
    [ "h_GpadcMin", "structT__RL__API__MON__LIVE__GAPDC__CTM__RESULT.html#a364ce32a5849c5016fe2178c2174a321", null ],
    [ "w_GpadcSum", "structT__RL__API__MON__LIVE__GAPDC__CTM__RESULT.html#acbe1a2bc3782f839c40264b7f937e068", null ]
];