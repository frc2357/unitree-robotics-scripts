var structT__RL__API__FECSS__DEV__PWR__OFF__CMD =
[
    [ "c_Reserved1", "structT__RL__API__FECSS__DEV__PWR__OFF__CMD.html#ad96962542b1b0b9bbad845921adee9b0", null ],
    [ "c_RetentionMode", "structT__RL__API__FECSS__DEV__PWR__OFF__CMD.html#abf60b087be3a13082dee5bb0302e5030", null ],
    [ "h_Reserved2", "structT__RL__API__FECSS__DEV__PWR__OFF__CMD.html#af6916cc7db5fbc2060e7cfe6bf4c12a9", null ],
    [ "w_Reserved3", "structT__RL__API__FECSS__DEV__PWR__OFF__CMD.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ]
];