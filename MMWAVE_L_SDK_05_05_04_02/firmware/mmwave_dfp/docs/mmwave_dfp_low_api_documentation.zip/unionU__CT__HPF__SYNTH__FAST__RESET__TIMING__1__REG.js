var unionU__CT__HPF__SYNTH__FAST__RESET__TIMING__1__REG =
[
    [ "b32_Reg", "unionU__CT__HPF__SYNTH__FAST__RESET__TIMING__1__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_HpfFastInitPulseWidth", "unionU__CT__HPF__SYNTH__FAST__RESET__TIMING__1__REG.html#aebdfa4da9c99ab85795f3c32bfc20219", null ],
    [ "b8_HpfFastInitStartTime", "unionU__CT__HPF__SYNTH__FAST__RESET__TIMING__1__REG.html#a9c49a515f951010db9dcb54aa179ae5f", null ],
    [ "b8_SynthFastResetEndTime1", "unionU__CT__HPF__SYNTH__FAST__RESET__TIMING__1__REG.html#a981330a2d3de65a32765fff137d55b6b", null ],
    [ "b8_SynthFastResetStartTime1", "unionU__CT__HPF__SYNTH__FAST__RESET__TIMING__1__REG.html#a868a06f8b1b2b8d677bc5122b994f51d", null ],
    [ "bits", "unionU__CT__HPF__SYNTH__FAST__RESET__TIMING__1__REG.html#ae36bd60d6a6aa59abc4339e2c733355b", null ]
];