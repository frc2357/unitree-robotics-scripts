var unionU__CT__PERCHIRP__PARAMETER__LEN1 =
[
    [ "b16_PerchirpFreqSlopeLen", "unionU__CT__PERCHIRP__PARAMETER__LEN1.html#a71fad49c59884388cb048fcfd41b6525", null ],
    [ "b16_PerchirpFreqStartLen", "unionU__CT__PERCHIRP__PARAMETER__LEN1.html#a8f894764932b6567d5abb41283e66933", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__PARAMETER__LEN1.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__PARAMETER__LEN1.html#a1785086253a76dc398eafdd85b7a1fff", null ]
];