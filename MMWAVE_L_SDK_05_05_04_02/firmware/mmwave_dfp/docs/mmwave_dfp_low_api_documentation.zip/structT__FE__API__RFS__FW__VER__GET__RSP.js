var structT__FE__API__RFS__FW__VER__GET__RSP =
[
    [ "z_PatchVersion", "structT__FE__API__RFS__FW__VER__GET__RSP.html#a498b22319810224d6aaaae8ba6accf2c", null ],
    [ "z_RomVersion", "structT__FE__API__RFS__FW__VER__GET__RSP.html#a8bd93a79627179402b83493623a6ee72", null ]
];