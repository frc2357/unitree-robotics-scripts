var unionU__CT__PERCHIRP__PARAMETER__ADDR2 =
[
    [ "b16_PerchirpAdcStartTimeAddr", "unionU__CT__PERCHIRP__PARAMETER__ADDR2.html#a0e5aeb2a05b4b0241695ed53e223d8f7", null ],
    [ "b16_PerchirpIdleTimeAddr", "unionU__CT__PERCHIRP__PARAMETER__ADDR2.html#af7c6d53347c9c45c2ce05d6f297d407e", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__PARAMETER__ADDR2.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__PARAMETER__ADDR2.html#af1e4dc6316ed70dcc19639eeca7ddd9a", null ]
];