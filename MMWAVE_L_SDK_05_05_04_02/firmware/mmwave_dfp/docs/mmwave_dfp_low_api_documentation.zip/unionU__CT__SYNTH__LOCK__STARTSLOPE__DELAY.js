var unionU__CT__SYNTH__LOCK__STARTSLOPE__DELAY =
[
    [ "b16_Padfield_0", "unionU__CT__SYNTH__LOCK__STARTSLOPE__DELAY.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b16_SynthLockStartslopeDelay", "unionU__CT__SYNTH__LOCK__STARTSLOPE__DELAY.html#a9f596bc75bd9943403a41a00963374d5", null ],
    [ "b32_Reg", "unionU__CT__SYNTH__LOCK__STARTSLOPE__DELAY.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__SYNTH__LOCK__STARTSLOPE__DELAY.html#a909525dff4985fb042c4205bbf10287f", null ]
];