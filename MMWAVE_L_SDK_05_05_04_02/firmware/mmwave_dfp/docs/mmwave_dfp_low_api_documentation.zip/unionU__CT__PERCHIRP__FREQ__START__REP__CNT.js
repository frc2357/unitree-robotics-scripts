var unionU__CT__PERCHIRP__FREQ__START__REP__CNT =
[
    [ "b16_Padfield_0", "unionU__CT__PERCHIRP__FREQ__START__REP__CNT.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b16_PerchirpFreqStartRepCnt", "unionU__CT__PERCHIRP__FREQ__START__REP__CNT.html#aaec8036d4446d163ab1630dad7238133", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__FREQ__START__REP__CNT.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__FREQ__START__REP__CNT.html#abd010df3b7cd4cac1a80f2172ae18d14", null ]
];