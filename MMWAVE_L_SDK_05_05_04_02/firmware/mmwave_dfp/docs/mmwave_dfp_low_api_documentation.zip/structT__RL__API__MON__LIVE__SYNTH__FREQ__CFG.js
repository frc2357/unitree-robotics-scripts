var structT__RL__API__MON__LIVE__SYNTH__FREQ__CFG =
[
    [ "c_Reserved1", "structT__RL__API__MON__LIVE__SYNTH__FREQ__CFG.html#ad96962542b1b0b9bbad845921adee9b0", null ],
    [ "h_FreqErrThreshold", "structT__RL__API__MON__LIVE__SYNTH__FREQ__CFG.html#af202b31d7ea99c6769a33e6692a95de6", null ],
    [ "w_Reserved2", "structT__RL__API__MON__LIVE__SYNTH__FREQ__CFG.html#adad85885669e932d55697b63bec2a941", null ],
    [ "w_Reserved3", "structT__RL__API__MON__LIVE__SYNTH__FREQ__CFG.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ],
    [ "xc_ChirpMonStartTime", "structT__RL__API__MON__LIVE__SYNTH__FREQ__CFG.html#ac49bcb9be509951d469eae1a85a6bc95", null ]
];