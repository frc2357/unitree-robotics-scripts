var unionU__CT__RAPID__EN__OVERRIDE__RX__REG =
[
    [ "b11_Padfield_0", "unionU__CT__RAPID__EN__OVERRIDE__RX__REG.html#a9a072e3f3c40cf9cd6160b67cecd5a83", null ],
    [ "b1_RapidEnLoRxallOverride", "unionU__CT__RAPID__EN__OVERRIDE__RX__REG.html#ad9ac2989156dc429210e47ea0db8efbb", null ],
    [ "b32_Reg", "unionU__CT__RAPID__EN__OVERRIDE__RX__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b4_RapidEnBbRxOverride", "unionU__CT__RAPID__EN__OVERRIDE__RX__REG.html#aa976e421d407242846e68448e69d90cc", null ],
    [ "b8_RapidEnRfRxOverride", "unionU__CT__RAPID__EN__OVERRIDE__RX__REG.html#a5e11a2a7964e0ee723b367d71561914e", null ],
    [ "b8_Reserved", "unionU__CT__RAPID__EN__OVERRIDE__RX__REG.html#a6b31ed22c44108b1c18c3b45417ddbf7", null ],
    [ "bits", "unionU__CT__RAPID__EN__OVERRIDE__RX__REG.html#ac7a61a7e95da666d642104544acd9db6", null ]
];