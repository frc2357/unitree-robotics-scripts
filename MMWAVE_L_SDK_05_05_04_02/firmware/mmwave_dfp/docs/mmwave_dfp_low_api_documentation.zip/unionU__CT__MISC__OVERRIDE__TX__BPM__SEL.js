var unionU__CT__MISC__OVERRIDE__TX__BPM__SEL =
[
    [ "b16_Padfield_0", "unionU__CT__MISC__OVERRIDE__TX__BPM__SEL.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b16_TxBpmOverrideSel", "unionU__CT__MISC__OVERRIDE__TX__BPM__SEL.html#a8dca8f36777d6a436ce6e2071558c889", null ],
    [ "b32_Reg", "unionU__CT__MISC__OVERRIDE__TX__BPM__SEL.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__MISC__OVERRIDE__TX__BPM__SEL.html#aa4e0ccfb45bce330f7fb958e687d441a", null ]
];