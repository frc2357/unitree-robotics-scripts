var structT__RL__API__SENS__FRAME__CFG =
[
    [ "c_MiscSetupMask", "structT__RL__API__SENS__FRAME__CFG.html#a76e0a7cddfafea11bb27d1fc9f8223c1", null ],
    [ "c_NumOfChirpsAccum", "structT__RL__API__SENS__FRAME__CFG.html#a3c690eb3c1310c77797f114dc453f1a8", null ],
    [ "h_NumOfBurstsInFrame", "structT__RL__API__SENS__FRAME__CFG.html#ae1b73d30c2a75836599ca7904871862b", null ],
    [ "h_NumOfChirpsInBurst", "structT__RL__API__SENS__FRAME__CFG.html#adad4392c747157ff5e2429e6b25024a4", null ],
    [ "h_NumOfFrames", "structT__RL__API__SENS__FRAME__CFG.html#ad99768385c4f7be27bf93db5519ce13d", null ],
    [ "h_Reserved1", "structT__RL__API__SENS__FRAME__CFG.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "h_Reserved2", "structT__RL__API__SENS__FRAME__CFG.html#af6916cc7db5fbc2060e7cfe6bf4c12a9", null ],
    [ "w_BurstPeriodicity", "structT__RL__API__SENS__FRAME__CFG.html#ab858477d26b86792c25b655f126345a4", null ],
    [ "w_FrameEvent0TimeCfg", "structT__RL__API__SENS__FRAME__CFG.html#a0a15595781fd15c880bd454bfef50700", null ],
    [ "w_FrameEvent1TimeCfg", "structT__RL__API__SENS__FRAME__CFG.html#a90e85cb0fa63a89461d44469c096c5fb", null ],
    [ "w_FramePeriodicity", "structT__RL__API__SENS__FRAME__CFG.html#ab2a104688c74435a4f7265fdce17fc49", null ],
    [ "w_Reserved3", "structT__RL__API__SENS__FRAME__CFG.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ]
];