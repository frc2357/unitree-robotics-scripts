var unionU__CT__RAPID__EN__OVERRIDE__SEL__TX__REG =
[
    [ "b23_Padfield_0", "unionU__CT__RAPID__EN__OVERRIDE__SEL__TX__REG.html#a0975a0ef43fcbc5f916d2aa107c9aebe", null ],
    [ "b32_Reg", "unionU__CT__RAPID__EN__OVERRIDE__SEL__TX__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b9_RapidEnOverrideSelTx", "unionU__CT__RAPID__EN__OVERRIDE__SEL__TX__REG.html#a4e988c392ca57e425d2a1351da57d403", null ],
    [ "bits", "unionU__CT__RAPID__EN__OVERRIDE__SEL__TX__REG.html#a8ba2f683eeb3b809d8609a318185d24e", null ]
];