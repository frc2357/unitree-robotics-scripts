var structT__RL__API__MON__PLL__CTRL__VOLT__CFG =
[
    [ "c_PllMonEnaMask", "structT__RL__API__MON__PLL__CTRL__VOLT__CFG.html#a202ead2aba874e357f7a38512040845a", null ],
    [ "c_Reserved1", "structT__RL__API__MON__PLL__CTRL__VOLT__CFG.html#ad96962542b1b0b9bbad845921adee9b0", null ],
    [ "h_Reserved2", "structT__RL__API__MON__PLL__CTRL__VOLT__CFG.html#af6916cc7db5fbc2060e7cfe6bf4c12a9", null ],
    [ "w_Reserved3", "structT__RL__API__MON__PLL__CTRL__VOLT__CFG.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ]
];