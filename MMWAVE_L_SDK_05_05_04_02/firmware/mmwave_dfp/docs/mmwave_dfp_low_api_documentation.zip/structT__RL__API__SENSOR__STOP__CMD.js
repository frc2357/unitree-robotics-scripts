var structT__RL__API__SENSOR__STOP__CMD =
[
    [ "c_FrameStopMode", "structT__RL__API__SENSOR__STOP__CMD.html#ae87c81d30b4ba0260075e27c1ab3b365", null ],
    [ "c_Reserved", "structT__RL__API__SENSOR__STOP__CMD.html#a8cb7e44eb1c3f29be371c2ab8ab20d6b", null ],
    [ "h_Reserved1", "structT__RL__API__SENSOR__STOP__CMD.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "w_Reserved2", "structT__RL__API__SENSOR__STOP__CMD.html#adad85885669e932d55697b63bec2a941", null ]
];