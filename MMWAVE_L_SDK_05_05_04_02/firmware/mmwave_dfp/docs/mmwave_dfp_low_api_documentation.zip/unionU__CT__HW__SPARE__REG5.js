var unionU__CT__HW__SPARE__REG5 =
[
    [ "b32_HwSpareReg5", "unionU__CT__HW__SPARE__REG5.html#aa919ff4168e2df5d93868e360a779a7d", null ],
    [ "b32_Reg", "unionU__CT__HW__SPARE__REG5.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__HW__SPARE__REG5.html#a5d4afd1bcc47a642a1063ec89eeeda0f", null ]
];