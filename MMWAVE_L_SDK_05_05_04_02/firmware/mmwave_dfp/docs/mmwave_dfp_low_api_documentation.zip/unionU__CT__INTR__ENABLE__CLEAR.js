var unionU__CT__INTR__ENABLE__CLEAR =
[
    [ "b1_AddrErrEnClr", "unionU__CT__INTR__ENABLE__CLEAR.html#a3dcc82751b5ee4d9d51f82e6344b1d4e", null ],
    [ "b1_KickErrEnClr", "unionU__CT__INTR__ENABLE__CLEAR.html#a59fb34b5f64772e9899fdef17cf81126", null ],
    [ "b1_ProtErrEnClr", "unionU__CT__INTR__ENABLE__CLEAR.html#ad7edde5001cc201f649cb26251e62117", null ],
    [ "b1_ProxyErrEnClr", "unionU__CT__INTR__ENABLE__CLEAR.html#a04ec447a8c8a20ccc341b7c38cbb1ffe", null ],
    [ "b28_Padfield_0", "unionU__CT__INTR__ENABLE__CLEAR.html#a695ce030f1b67b139d277466993c83a0", null ],
    [ "b32_Reg", "unionU__CT__INTR__ENABLE__CLEAR.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__INTR__ENABLE__CLEAR.html#a00f78ee79ab921de3e1605b846fc6cfd", null ]
];