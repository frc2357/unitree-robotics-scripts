var unionU__CT__HW__SPARE__REG1 =
[
    [ "b32_HwSpareReg1", "unionU__CT__HW__SPARE__REG1.html#a6b1e28c26b56fd25b1404cde0aafebdd", null ],
    [ "b32_Reg", "unionU__CT__HW__SPARE__REG1.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__HW__SPARE__REG1.html#a4b32fca71a0fbd096447d837d58c5243", null ]
];