var structT__RL__API__FECSS__RFS__DBG__CFG__CMD =
[
    [ "w_Reserved0", "structT__RL__API__FECSS__RFS__DBG__CFG__CMD.html#a543e88bbec44f0b73b3754e7f593942f", null ],
    [ "w_Reserved1", "structT__RL__API__FECSS__RFS__DBG__CFG__CMD.html#a94b7e367d00db535542e6e8c74eeb78a", null ],
    [ "w_RfsDbgLogAddress", "structT__RL__API__FECSS__RFS__DBG__CFG__CMD.html#ab5ff0ea741973c612f90e9588d925339", null ]
];