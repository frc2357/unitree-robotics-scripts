var unionU__CT__BURST__PERIOD__TIMER =
[
    [ "b32_BurstPeriodTimer", "unionU__CT__BURST__PERIOD__TIMER.html#a09c2d69b8af41b3a4391f89e7ca367da", null ],
    [ "b32_Reg", "unionU__CT__BURST__PERIOD__TIMER.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__BURST__PERIOD__TIMER.html#a39bda8edb35527ec9fb3a456cf4a8012", null ]
];