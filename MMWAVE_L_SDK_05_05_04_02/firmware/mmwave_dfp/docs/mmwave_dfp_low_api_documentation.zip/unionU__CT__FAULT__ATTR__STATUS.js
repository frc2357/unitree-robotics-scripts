var unionU__CT__FAULT__ATTR__STATUS =
[
    [ "b12_FaultRouteid", "unionU__CT__FAULT__ATTR__STATUS.html#af7a01fe1bfa207bdb39a14104ec7affc", null ],
    [ "b12_FaultXid", "unionU__CT__FAULT__ATTR__STATUS.html#a6e81c26e5bb090513284074ed1a396d8", null ],
    [ "b32_Reg", "unionU__CT__FAULT__ATTR__STATUS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_FaultPrivid", "unionU__CT__FAULT__ATTR__STATUS.html#a32d0febf7d903172e7cd564ad8bb2d8f", null ],
    [ "bits", "unionU__CT__FAULT__ATTR__STATUS.html#ab9b42f529bf01cfd2da7093294832bde", null ]
];