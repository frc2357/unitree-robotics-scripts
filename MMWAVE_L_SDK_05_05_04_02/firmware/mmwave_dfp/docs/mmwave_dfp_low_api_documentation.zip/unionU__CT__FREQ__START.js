var unionU__CT__FREQ__START =
[
    [ "b24_FreqStart", "unionU__CT__FREQ__START.html#a857697bfcc2c77504a5d4a40b20392bb", null ],
    [ "b32_Reg", "unionU__CT__FREQ__START.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_Padfield_0", "unionU__CT__FREQ__START.html#a69b308cc2c42c40c7788924b4aae5c55", null ],
    [ "bits", "unionU__CT__FREQ__START.html#a6cd3410d6dc9523de5a4147ca26d0488", null ]
];