var unionU__CT__RAPID__EN__RF__RX5__END__TIME__REG =
[
    [ "b32_Reg", "unionU__CT__RAPID__EN__RF__RX5__END__TIME__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_RapidEnRfRx5EndTime", "unionU__CT__RAPID__EN__RF__RX5__END__TIME__REG.html#abd7ce541332e85c559a5d788e641e9d7", null ],
    [ "b8_RapidEnRfRx6EndTime", "unionU__CT__RAPID__EN__RF__RX5__END__TIME__REG.html#ae44433c7db585c79bb5604eabf3088c8", null ],
    [ "b8_RapidEnRfRx7EndTime", "unionU__CT__RAPID__EN__RF__RX5__END__TIME__REG.html#a7977ef0701eddc55f25618b446633795", null ],
    [ "b8_RapidEnRfRx8EndTime", "unionU__CT__RAPID__EN__RF__RX5__END__TIME__REG.html#a31aa1c4798a6c03f37f6488534dbd3ad", null ],
    [ "bits", "unionU__CT__RAPID__EN__RF__RX5__END__TIME__REG.html#a1ac01e47cea3b4f03e8afbab022dffb3", null ]
];