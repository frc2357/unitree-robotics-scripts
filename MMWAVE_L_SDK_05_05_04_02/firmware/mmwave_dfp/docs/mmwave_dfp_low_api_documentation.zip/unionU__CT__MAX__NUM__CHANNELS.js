var unionU__CT__MAX__NUM__CHANNELS =
[
    [ "b16_Padfield_0", "unionU__CT__MAX__NUM__CHANNELS.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b32_Reg", "unionU__CT__MAX__NUM__CHANNELS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_MaxNumRxChannels", "unionU__CT__MAX__NUM__CHANNELS.html#abf056fde0a1ecdcf5ebbd3a5962ea6c6", null ],
    [ "b8_MaxNumTxChannels", "unionU__CT__MAX__NUM__CHANNELS.html#ab7ab144d6d6a70bfe5b7de4a390dfc34", null ],
    [ "bits", "unionU__CT__MAX__NUM__CHANNELS.html#a5c8058e5d12d49e52481ce63ce3fe967", null ]
];