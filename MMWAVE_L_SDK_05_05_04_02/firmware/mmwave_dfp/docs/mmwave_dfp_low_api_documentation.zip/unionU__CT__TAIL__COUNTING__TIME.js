var unionU__CT__TAIL__COUNTING__TIME =
[
    [ "b24_Padfield_0", "unionU__CT__TAIL__COUNTING__TIME.html#a5eee3a45ed8ea134718d5c80b151fa5c", null ],
    [ "b32_Reg", "unionU__CT__TAIL__COUNTING__TIME.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_TailCountingTime", "unionU__CT__TAIL__COUNTING__TIME.html#a2d0a00909b6b8d1a30983b751109f70a", null ],
    [ "bits", "unionU__CT__TAIL__COUNTING__TIME.html#a6f305569710178ee300c5fa10d7b69b9", null ]
];