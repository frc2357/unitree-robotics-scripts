var unionU__CT__RAMP__END__TIME =
[
    [ "b16_Padfield_0", "unionU__CT__RAMP__END__TIME.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b16_RampEndTime", "unionU__CT__RAMP__END__TIME.html#a42da8e67df43f337fc482ca8737795cd", null ],
    [ "b32_Reg", "unionU__CT__RAMP__END__TIME.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__RAMP__END__TIME.html#a81c0a5a91076ea95a8ddf8ab167a7633", null ]
];