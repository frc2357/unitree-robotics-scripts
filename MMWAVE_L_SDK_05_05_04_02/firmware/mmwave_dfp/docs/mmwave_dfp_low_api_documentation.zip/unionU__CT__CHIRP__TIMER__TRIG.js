var unionU__CT__CHIRP__TIMER__TRIG =
[
    [ "b1_ChirpTimerCwCzEn", "unionU__CT__CHIRP__TIMER__TRIG.html#acecc66f75b28913667408ae4aac7408d", null ],
    [ "b1_ChirpTimerTrigSrcSel", "unionU__CT__CHIRP__TIMER__TRIG.html#ab38ff9898c9526e006098c3624c741c7", null ],
    [ "b24_Padfield_0", "unionU__CT__CHIRP__TIMER__TRIG.html#a5eee3a45ed8ea134718d5c80b151fa5c", null ],
    [ "b32_Reg", "unionU__CT__CHIRP__TIMER__TRIG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b3_ChirpTimerStopReg", "unionU__CT__CHIRP__TIMER__TRIG.html#a57e32dddfd9ee8e81d02bab271e637c7", null ],
    [ "b3_ChirpTimerTrigReg", "unionU__CT__CHIRP__TIMER__TRIG.html#ae8327cad9d6539a1713a3767bb9f17b9", null ],
    [ "bits", "unionU__CT__CHIRP__TIMER__TRIG.html#a095a9d1614407ee5066f691a1295cadc", null ]
];