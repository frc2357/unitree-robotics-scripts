var unionU__CT__PERCHIRP__PARAMETER__ADDR1 =
[
    [ "b16_PerchirpFreqSlopeAddr", "unionU__CT__PERCHIRP__PARAMETER__ADDR1.html#a324b73b003809ef77d07f281323cc537", null ],
    [ "b16_PerchirpFreqStartAddr", "unionU__CT__PERCHIRP__PARAMETER__ADDR1.html#af67061006de850e59ec24cd0f54bfce5", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__PARAMETER__ADDR1.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__PARAMETER__ADDR1.html#a304288a640244b2b0a5bff1bd6075fff", null ]
];