var unionU__CT__INTR__ENABLE =
[
    [ "b1_AddrErrEn", "unionU__CT__INTR__ENABLE.html#af560937c740541f292b62706353392af", null ],
    [ "b1_KickErrEn", "unionU__CT__INTR__ENABLE.html#a53217b4f01c197af752a5f9eddaac35f", null ],
    [ "b1_ProtErrEn", "unionU__CT__INTR__ENABLE.html#a035c57d37b3dc17c9f9933c012764216", null ],
    [ "b1_ProxyErrEn", "unionU__CT__INTR__ENABLE.html#abf75d1e72af433c219bd836db5712285", null ],
    [ "b28_Padfield_0", "unionU__CT__INTR__ENABLE.html#a695ce030f1b67b139d277466993c83a0", null ],
    [ "b32_Reg", "unionU__CT__INTR__ENABLE.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__INTR__ENABLE.html#ab122d1d059de9932a8c4a828fbf4f99e", null ]
];