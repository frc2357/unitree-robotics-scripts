var structT__FE__DEVICE__DATA =
[
    [ "p_ComIfHdl", "structT__FE__DEVICE__DATA.html#ae71a07338480fd266b21ee34cfd9b12f", null ],
    [ "p_MutexHdl", "structT__FE__DEVICE__DATA.html#ac7c9e87686bbad5c7a61d293ca029cc6", null ],
    [ "p_PltHwiHdl", "structT__FE__DEVICE__DATA.html#af6d1ad7fc4ef5b2b93ff070e611b4415", null ],
    [ "p_SemHdl", "structT__FE__DEVICE__DATA.html#aef9f48b172a148e67839ed0fb6bfcb78", null ]
];