var structT__RL__API__MON__LIVE__RX__SATURATION__CFG =
[
    [ "h_PerChirpRamStartAdd", "structT__RL__API__MON__LIVE__RX__SATURATION__CFG.html#ace83b3b0d85413ddfb1a5569721838d1", null ],
    [ "h_Reserved1", "structT__RL__API__MON__LIVE__RX__SATURATION__CFG.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "w_Reserved2", "structT__RL__API__MON__LIVE__RX__SATURATION__CFG.html#adad85885669e932d55697b63bec2a941", null ]
];