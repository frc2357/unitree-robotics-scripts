var structT__RL__API__FECSS__GPADC__MEAS__RSP =
[
    [ "c_GpadcChRunStatus", "structT__RL__API__FECSS__GPADC__MEAS__RSP.html#af5d8beaca7f116f54d833c4775794239", null ],
    [ "c_GpadcMeasVal", "structT__RL__API__FECSS__GPADC__MEAS__RSP.html#a9ee7f2c9741920e55aea80905bd4d6a8", null ],
    [ "c_Reserved1", "structT__RL__API__FECSS__GPADC__MEAS__RSP.html#ad96962542b1b0b9bbad845921adee9b0", null ],
    [ "h_Reserved2", "structT__RL__API__FECSS__GPADC__MEAS__RSP.html#af6916cc7db5fbc2060e7cfe6bf4c12a9", null ],
    [ "w_Reserved3", "structT__RL__API__FECSS__GPADC__MEAS__RSP.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ],
    [ "w_Reserved4", "structT__RL__API__FECSS__GPADC__MEAS__RSP.html#a9fdf5cd48e45afcc69617cf33021ac93", null ]
];