var structT__RL__API__MON__DBG__TXPWR__MEAS__CMD =
[
    [ "c_Reserved0", "structT__RL__API__MON__DBG__TXPWR__MEAS__CMD.html#a6e359a94ca4b7990d84c829a1183205b", null ],
    [ "c_TxBackoff", "structT__RL__API__MON__DBG__TXPWR__MEAS__CMD.html#ae3bc669dc55ecad0e756dcc16aef1ce0", null ],
    [ "c_TxIndex", "structT__RL__API__MON__DBG__TXPWR__MEAS__CMD.html#a42988ddf3dc407cb5f6e0adac6efca27", null ],
    [ "c_TxPwrNAccum", "structT__RL__API__MON__DBG__TXPWR__MEAS__CMD.html#a798cc92ea73ef70bea277c02e9f2c78e", null ],
    [ "w_Reserved1", "structT__RL__API__MON__DBG__TXPWR__MEAS__CMD.html#a94b7e367d00db535542e6e8c74eeb78a", null ],
    [ "w_Reserved2", "structT__RL__API__MON__DBG__TXPWR__MEAS__CMD.html#adad85885669e932d55697b63bec2a941", null ]
];