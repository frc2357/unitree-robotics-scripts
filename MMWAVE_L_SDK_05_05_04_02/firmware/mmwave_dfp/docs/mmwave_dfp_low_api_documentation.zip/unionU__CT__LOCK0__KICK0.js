var unionU__CT__LOCK0__KICK0 =
[
    [ "b32_Reg", "unionU__CT__LOCK0__KICK0.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b32_Value", "unionU__CT__LOCK0__KICK0.html#a455f75cc0afd22fcfd63f1be0339b02f", null ],
    [ "bits", "unionU__CT__LOCK0__KICK0.html#a19a68dbb6b02189d94286a1c0eef153a", null ]
];