var unionU__CT__HW__SPARE__REG3 =
[
    [ "b32_HwSpareReg3", "unionU__CT__HW__SPARE__REG3.html#ad592c9c21da4a391ac95aa7add90f44b", null ],
    [ "b32_Reg", "unionU__CT__HW__SPARE__REG3.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__HW__SPARE__REG3.html#a017c9a4aa2b5ce2e008cc492cc0c70e6", null ]
];