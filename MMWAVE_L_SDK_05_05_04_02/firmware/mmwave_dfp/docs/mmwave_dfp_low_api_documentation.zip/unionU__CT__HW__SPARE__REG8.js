var unionU__CT__HW__SPARE__REG8 =
[
    [ "b32_HwSpareReg8", "unionU__CT__HW__SPARE__REG8.html#ac08e7b6d9489c9387fd75a0c0c2a972e", null ],
    [ "b32_Reg", "unionU__CT__HW__SPARE__REG8.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__HW__SPARE__REG8.html#a13d13f902d4b8eda7722c5f989d1dacf", null ]
];