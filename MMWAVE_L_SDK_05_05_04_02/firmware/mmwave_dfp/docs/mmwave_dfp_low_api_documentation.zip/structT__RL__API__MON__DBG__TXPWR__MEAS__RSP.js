var structT__RL__API__MON__DBG__TXPWR__MEAS__RSP =
[
    [ "h_Reserved1", "structT__RL__API__MON__DBG__TXPWR__MEAS__RSP.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "w_Reserved2", "structT__RL__API__MON__DBG__TXPWR__MEAS__RSP.html#adad85885669e932d55697b63bec2a941", null ],
    [ "w_TxIncidentVolt", "structT__RL__API__MON__DBG__TXPWR__MEAS__RSP.html#afa534ea5d28e534f47ce1eb17ab6ee82", null ],
    [ "w_TxReflectedVolt", "structT__RL__API__MON__DBG__TXPWR__MEAS__RSP.html#ac1c66c2b71a6eb82750ff290325fe076", null ],
    [ "xh_TxIncidentPwr", "structT__RL__API__MON__DBG__TXPWR__MEAS__RSP.html#afdc1e4919da117e9824f8233da7783cc", null ],
    [ "xh_TxPower", "structT__RL__API__MON__DBG__TXPWR__MEAS__RSP.html#aeee128b34aa94995efeaee8dca6cfdcc", null ],
    [ "xh_TxReflectedPwr", "structT__RL__API__MON__DBG__TXPWR__MEAS__RSP.html#a30a8fc5330d53f7a25a601e3e81477eb", null ]
];