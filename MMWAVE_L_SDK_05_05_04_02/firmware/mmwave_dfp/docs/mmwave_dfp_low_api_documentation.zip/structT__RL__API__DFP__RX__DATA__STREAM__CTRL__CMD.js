var structT__RL__API__DFP__RX__DATA__STREAM__CTRL__CMD =
[
    [ "c_Reserved", "structT__RL__API__DFP__RX__DATA__STREAM__CTRL__CMD.html#ae15beec15fd2067ab4885a9fc6179d1e", null ],
    [ "c_StreamEn", "structT__RL__API__DFP__RX__DATA__STREAM__CTRL__CMD.html#a5132def2047d92dc41dbadcd45a92151", null ]
];