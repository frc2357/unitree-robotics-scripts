var unionU__CT__HW__SPARE__REG6 =
[
    [ "b32_HwSpareReg6", "unionU__CT__HW__SPARE__REG6.html#a9ba711ab98b806d545ad6358e46d1e5f", null ],
    [ "b32_Reg", "unionU__CT__HW__SPARE__REG6.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__HW__SPARE__REG6.html#a8a178eef05168837c1b68df57fa969df", null ]
];