var unionU__CT__PARAM__WAIT__UPDATE__CYCLES =
[
    [ "b19_Padfield_1", "unionU__CT__PARAM__WAIT__UPDATE__CYCLES.html#a3e9075967b42d9cab37b554ca349b9c9", null ],
    [ "b1_Padfield_0", "unionU__CT__PARAM__WAIT__UPDATE__CYCLES.html#a52971a89fa014b5e6a9339583402d9ba", null ],
    [ "b32_Reg", "unionU__CT__PARAM__WAIT__UPDATE__CYCLES.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b6_ParamUpdateCycles", "unionU__CT__PARAM__WAIT__UPDATE__CYCLES.html#a73b24b1d29b41c33efcd251cf11c61e2", null ],
    [ "b6_ParamWaitCycles", "unionU__CT__PARAM__WAIT__UPDATE__CYCLES.html#a2f661998bb79d3d160e73088e6521f3d", null ],
    [ "bits", "unionU__CT__PARAM__WAIT__UPDATE__CYCLES.html#a576229ae56a13c09b3cae7d14f6e2d00", null ]
];