var structT__RL__API__MON__TXN__BB__RESULT =
[
    [ "h_Reserved1", "structT__RL__API__MON__TXN__BB__RESULT.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "w_FrameCount", "structT__RL__API__MON__TXN__BB__RESULT.html#a4186c07ac82a66607babd235976572cd", null ],
    [ "w_Reserved2", "structT__RL__API__MON__TXN__BB__RESULT.html#adad85885669e932d55697b63bec2a941", null ],
    [ "xh_ErrorCode", "structT__RL__API__MON__TXN__BB__RESULT.html#ad9a48e22c424c7ee64557d99729e6b46", null ],
    [ "xh_TxNIncidPwrVal", "structT__RL__API__MON__TXN__BB__RESULT.html#ac9d8d08a8acae9529deeb1236165d96b", null ],
    [ "xh_TxNReflPwrVal", "structT__RL__API__MON__TXN__BB__RESULT.html#ab3aadcff10ea00054246fbebe77323ce", null ]
];