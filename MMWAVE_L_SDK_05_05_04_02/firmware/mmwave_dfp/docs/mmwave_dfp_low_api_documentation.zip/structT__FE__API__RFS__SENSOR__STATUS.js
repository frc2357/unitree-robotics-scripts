var structT__FE__API__RFS__SENSOR__STATUS =
[
    [ "w_BurstEndCount", "structT__FE__API__RFS__SENSOR__STATUS.html#aacaf766dcd469a1d7862248d9dcaf72b", null ],
    [ "w_BurstStartCount", "structT__FE__API__RFS__SENSOR__STATUS.html#a53bdf9bcc3609180a3becfd673edf7da", null ],
    [ "w_FrameEndCount", "structT__FE__API__RFS__SENSOR__STATUS.html#a86182058f01763e485b7d8d37e24e442", null ],
    [ "w_FrameFreeRunCount", "structT__FE__API__RFS__SENSOR__STATUS.html#a42ae47ca27a54b9949e378f1b1a07601", null ],
    [ "w_FrameStartCount", "structT__FE__API__RFS__SENSOR__STATUS.html#a9e65d2e70298a2d696230a0f02d2d0b5", null ],
    [ "w_Reserved", "structT__FE__API__RFS__SENSOR__STATUS.html#ac0f32f34f773cdf8786e32afe4f7038f", null ],
    [ "w_RfsMonCfgStatus", "structT__FE__API__RFS__SENSOR__STATUS.html#a321db5f7fc4b1cccb7e1b15cbf973446", null ]
];