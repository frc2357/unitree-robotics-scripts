var unionU__CT__TX__EN__BPM__QPSK__SETTINGS =
[
    [ "b16_Padfield_0", "unionU__CT__TX__EN__BPM__QPSK__SETTINGS.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b16_TxBpm", "unionU__CT__TX__EN__BPM__QPSK__SETTINGS.html#abe63902617ebe6f0eaf308269cf2072b", null ],
    [ "b32_Reg", "unionU__CT__TX__EN__BPM__QPSK__SETTINGS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__TX__EN__BPM__QPSK__SETTINGS.html#aa00cbf17493540851abf367a6094e242", null ]
];