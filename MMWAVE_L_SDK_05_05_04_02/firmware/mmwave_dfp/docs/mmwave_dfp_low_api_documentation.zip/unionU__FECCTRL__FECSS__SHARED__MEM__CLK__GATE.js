var unionU__FECCTRL__FECSS__SHARED__MEM__CLK__GATE =
[
    [ "b1_FecEnable", "unionU__FECCTRL__FECSS__SHARED__MEM__CLK__GATE.html#a44992cdb8eba3d5b13d7c0a7cbaa1771", null ],
    [ "b1_HwaEnable", "unionU__FECCTRL__FECSS__SHARED__MEM__CLK__GATE.html#af8c5533b950193a209e39d4f30539808", null ],
    [ "b30_Padfield_0", "unionU__FECCTRL__FECSS__SHARED__MEM__CLK__GATE.html#a482f05bd45ca96da8c37490fc55266cb", null ],
    [ "b32_Reg", "unionU__FECCTRL__FECSS__SHARED__MEM__CLK__GATE.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__FECCTRL__FECSS__SHARED__MEM__CLK__GATE.html#a5a5ba43ed307cee020b062eccdcf6bc1", null ]
];