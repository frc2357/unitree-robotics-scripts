var structT__RL__API__MON__TXN__RX__LB__RESULT =
[
    [ "h_TxNRxLbBpmPhase", "structT__RL__API__MON__TXN__RX__LB__RESULT.html#a55b1ce5e96354cd11ac99d85c71a5150", null ],
    [ "h_TxNRxLbPhase", "structT__RL__API__MON__TXN__RX__LB__RESULT.html#a6508b9b597e2e51d38bdb20fec267e30", null ],
    [ "w_FrameCount", "structT__RL__API__MON__TXN__RX__LB__RESULT.html#a4186c07ac82a66607babd235976572cd", null ],
    [ "w_Reserved2", "structT__RL__API__MON__TXN__RX__LB__RESULT.html#adad85885669e932d55697b63bec2a941", null ],
    [ "w_Reserved3", "structT__RL__API__MON__TXN__RX__LB__RESULT.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ],
    [ "xc_TxNRxLbBpmNoise", "structT__RL__API__MON__TXN__RX__LB__RESULT.html#a92ba3e60d5355b5dc6cdb67d6bdd01d0", null ],
    [ "xc_TxNRxLbNoise", "structT__RL__API__MON__TXN__RX__LB__RESULT.html#a9720ef3b6fe85714bc26d7f1013e50f8", null ],
    [ "xh_ErrorCode", "structT__RL__API__MON__TXN__RX__LB__RESULT.html#ad9a48e22c424c7ee64557d99729e6b46", null ],
    [ "xh_RxInputPower", "structT__RL__API__MON__TXN__RX__LB__RESULT.html#a3e8a288b74aff4b7ef6134cdf708a1b7", null ],
    [ "xh_TxNRxLbBpmPower", "structT__RL__API__MON__TXN__RX__LB__RESULT.html#a0ac530361c1b1798c7aa67feaa74fbfc", null ],
    [ "xh_TxNRxLbPower", "structT__RL__API__MON__TXN__RX__LB__RESULT.html#a2ef4206eaba745f385545e3d633f2bc1", null ]
];