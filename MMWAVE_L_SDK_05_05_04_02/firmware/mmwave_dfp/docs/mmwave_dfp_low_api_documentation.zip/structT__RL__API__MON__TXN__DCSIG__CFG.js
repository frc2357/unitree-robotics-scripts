var structT__RL__API__MON__TXN__DCSIG__CFG =
[
    [ "c_MonTxCodesSel", "structT__RL__API__MON__TXN__DCSIG__CFG.html#a71ae817177725d417a0629c09dae679f", null ],
    [ "c_TxIndSel", "structT__RL__API__MON__TXN__DCSIG__CFG.html#af932c157a6fe165ba022bc0b6cea635a", null ],
    [ "h_MonTxBiasCodes", "structT__RL__API__MON__TXN__DCSIG__CFG.html#a30e15a09e638d42afe5d48c1ac6fc35c", null ],
    [ "h_RfFreqStart", "structT__RL__API__MON__TXN__DCSIG__CFG.html#ad498a6e150cfdc2499d08e74bdd3b346", null ],
    [ "w_Reserved1", "structT__RL__API__MON__TXN__DCSIG__CFG.html#a94b7e367d00db535542e6e8c74eeb78a", null ],
    [ "w_Reserved2", "structT__RL__API__MON__TXN__DCSIG__CFG.html#adad85885669e932d55697b63bec2a941", null ],
    [ "xh_RfFreqSlope", "structT__RL__API__MON__TXN__DCSIG__CFG.html#a672b33c2257b50752246a5b7195e154f", null ]
];