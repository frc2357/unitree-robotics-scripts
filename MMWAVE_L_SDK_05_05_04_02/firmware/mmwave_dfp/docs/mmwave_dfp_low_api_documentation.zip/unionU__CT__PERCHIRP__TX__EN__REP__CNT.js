var unionU__CT__PERCHIRP__TX__EN__REP__CNT =
[
    [ "b16_Padfield_0", "unionU__CT__PERCHIRP__TX__EN__REP__CNT.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b16_PerchirpTxEnRepCnt", "unionU__CT__PERCHIRP__TX__EN__REP__CNT.html#a4c6ac0ba1af5234103b79e458b0651b0", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__TX__EN__REP__CNT.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__TX__EN__REP__CNT.html#a31c3b63ed1dde92446ba3c4db6182ae9", null ]
];