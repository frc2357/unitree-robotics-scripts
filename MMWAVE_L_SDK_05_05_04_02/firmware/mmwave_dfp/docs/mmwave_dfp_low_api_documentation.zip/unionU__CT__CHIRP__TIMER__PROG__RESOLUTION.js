var unionU__CT__CHIRP__TIMER__PROG__RESOLUTION =
[
    [ "b1_FreqStartRes", "unionU__CT__CHIRP__TIMER__PROG__RESOLUTION.html#ac84d30741334ae219ac59ccf5bbd0519", null ],
    [ "b1_TimingParamsRes", "unionU__CT__CHIRP__TIMER__PROG__RESOLUTION.html#a6960039297398de13717a48a74ba4fc2", null ],
    [ "b30_Padfield_0", "unionU__CT__CHIRP__TIMER__PROG__RESOLUTION.html#a482f05bd45ca96da8c37490fc55266cb", null ],
    [ "b32_Reg", "unionU__CT__CHIRP__TIMER__PROG__RESOLUTION.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__CHIRP__TIMER__PROG__RESOLUTION.html#ac1bda3466faa07913e3db51a0f339c04", null ]
];