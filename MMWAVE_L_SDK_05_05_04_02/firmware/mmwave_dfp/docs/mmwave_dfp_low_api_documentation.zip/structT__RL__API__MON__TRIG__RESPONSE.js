var structT__RL__API__MON__TRIG__RESPONSE =
[
    [ "w_FrameCount", "structT__RL__API__MON__TRIG__RESPONSE.html#a4186c07ac82a66607babd235976572cd", null ],
    [ "w_MonitorStatus", "structT__RL__API__MON__TRIG__RESPONSE.html#a2b6052a1dea01f16e22cb08637f90158", null ],
    [ "w_Reserved2", "structT__RL__API__MON__TRIG__RESPONSE.html#adad85885669e932d55697b63bec2a941", null ],
    [ "w_Reserved3", "structT__RL__API__MON__TRIG__RESPONSE.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ]
];