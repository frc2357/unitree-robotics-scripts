var unionU__CT__PARITY__CFG__REG =
[
    [ "b1_ChirpTimerUndefinedStateMask", "unionU__CT__PARITY__CFG__REG.html#a62c4d2eff58ccf031cac756e56e0be68", null ],
    [ "b1_ParamRamAddrCntrParityAndOutputMask", "unionU__CT__PARITY__CFG__REG.html#af55e7bc318319b1b13d07d9d557e00dc", null ],
    [ "b1_ParamRamAddrCntrParityCompDis", "unionU__CT__PARITY__CFG__REG.html#adc244930de47f80871c87fd0e88b530a", null ],
    [ "b1_ParamRamAddrCntrParityOrOutputMask", "unionU__CT__PARITY__CFG__REG.html#aefb814d8944faff1ebca98f474a6850b", null ],
    [ "b1_ParamRamMemParityCompDis", "unionU__CT__PARITY__CFG__REG.html#af6532a81aef1d0330b38c665c678aae0", null ],
    [ "b1_ParamRamMemParityOutputMask", "unionU__CT__PARITY__CFG__REG.html#ad52e1dfd3e32caf403519d09da9df067", null ],
    [ "b1_ParityInversionEnable", "unionU__CT__PARITY__CFG__REG.html#aead705e623c30e0102971b4bf86c2095", null ],
    [ "b1_PerchirpMemIntrpUndefinedStateMask", "unionU__CT__PARITY__CFG__REG.html#ace9565aa6dd1041c1fc920823b506378", null ],
    [ "b24_Padfield_0", "unionU__CT__PARITY__CFG__REG.html#a5eee3a45ed8ea134718d5c80b151fa5c", null ],
    [ "b32_Reg", "unionU__CT__PARITY__CFG__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PARITY__CFG__REG.html#a43f4d0282622d48620c5ce27cc0aa196", null ]
];