var unionU__CT__BURST__PERIODICITY =
[
    [ "b24_BurstPeriodicity", "unionU__CT__BURST__PERIODICITY.html#ad48032323354f6c91fec2380d2b6d68a", null ],
    [ "b32_Reg", "unionU__CT__BURST__PERIODICITY.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_Padfield_0", "unionU__CT__BURST__PERIODICITY.html#a69b308cc2c42c40c7788924b4aae5c55", null ],
    [ "bits", "unionU__CT__BURST__PERIODICITY.html#a00b0ea3ebd33cc28f04c11d076447839", null ]
];