var unionU__CT__ADC__START__TIME =
[
    [ "b10_AdcStartTimeFrac", "unionU__CT__ADC__START__TIME.html#a86f09ac5b3ec8017cffcd5f58bad3f73", null ],
    [ "b16_Padfield_0", "unionU__CT__ADC__START__TIME.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b32_Reg", "unionU__CT__ADC__START__TIME.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b6_NumSkipSamples", "unionU__CT__ADC__START__TIME.html#a9d2b7201f2bc68826db739e7749f767b", null ],
    [ "bits", "unionU__CT__ADC__START__TIME.html#a5616eba31f4d5689156486e73c22f8b6", null ]
];