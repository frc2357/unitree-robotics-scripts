var unionU__CT__TX__MIMO__PATTERN =
[
    [ "b24_Padfield_0", "unionU__CT__TX__MIMO__PATTERN.html#a5eee3a45ed8ea134718d5c80b151fa5c", null ],
    [ "b32_Reg", "unionU__CT__TX__MIMO__PATTERN.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_TxMimoPattern", "unionU__CT__TX__MIMO__PATTERN.html#adf2fe3e38549528f531ab48eeb1edb8a", null ],
    [ "bits", "unionU__CT__TX__MIMO__PATTERN.html#af7b2c98b8ec64865261d0996a9d0bbee", null ]
];