var unionU__FECCTRL__FECSS__SW__INT =
[
    [ "b28_Padfield_0", "unionU__FECCTRL__FECSS__SW__INT.html#a695ce030f1b67b139d277466993c83a0", null ],
    [ "b32_Reg", "unionU__FECCTRL__FECSS__SW__INT.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b4_Pulse", "unionU__FECCTRL__FECSS__SW__INT.html#a1e78ff6d2118faa1a0bd04a2bd895f62", null ],
    [ "bits", "unionU__FECCTRL__FECSS__SW__INT.html#ae1dd76ab43c9265bd1f6edd3e829430c", null ]
];