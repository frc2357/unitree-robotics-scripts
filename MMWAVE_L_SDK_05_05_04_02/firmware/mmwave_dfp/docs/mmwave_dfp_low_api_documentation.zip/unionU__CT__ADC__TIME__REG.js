var unionU__CT__ADC__TIME__REG =
[
    [ "b32_Reg", "unionU__CT__ADC__TIME__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_AdcAnaEnRxallEndTime", "unionU__CT__ADC__TIME__REG.html#a6fab681d3fbe3a37d500dea6fad3b42e", null ],
    [ "b8_AdcAnaEnRxallStartTime", "unionU__CT__ADC__TIME__REG.html#ad904953388ae9c374294cda29dd5576c", null ],
    [ "b8_AdcIntRstzEnRxallEndTime", "unionU__CT__ADC__TIME__REG.html#aac19965e1ca5713eae9d12bf3e2bdf98", null ],
    [ "b8_AdcIntRstzEnRxallStartTime", "unionU__CT__ADC__TIME__REG.html#a5c4da7f2f47e22a15abe76ff0d91220c", null ],
    [ "bits", "unionU__CT__ADC__TIME__REG.html#a0fff7fe2afd51109b6935e0c17eff3da", null ]
];