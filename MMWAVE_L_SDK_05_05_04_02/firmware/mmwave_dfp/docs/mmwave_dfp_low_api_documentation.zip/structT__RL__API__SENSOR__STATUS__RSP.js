var structT__RL__API__SENSOR__STATUS__RSP =
[
    [ "c_FrameStartStopStatus", "structT__RL__API__SENSOR__STATUS__RSP.html#a6a60b1f9cc0dab56ad27840bcd8bc729", null ],
    [ "c_Reserved1", "structT__RL__API__SENSOR__STATUS__RSP.html#ad96962542b1b0b9bbad845921adee9b0", null ],
    [ "h_BurstCount", "structT__RL__API__SENSOR__STATUS__RSP.html#a7f6f5d96c287303565157dc18d6876db", null ],
    [ "h_FrameCount", "structT__RL__API__SENSOR__STATUS__RSP.html#adbd8539eb56141cc86feb63a767ed1a0", null ],
    [ "h_Reserved2", "structT__RL__API__SENSOR__STATUS__RSP.html#af6916cc7db5fbc2060e7cfe6bf4c12a9", null ],
    [ "w_BurstPeriodTimerVal", "structT__RL__API__SENSOR__STATUS__RSP.html#a5d231bc49b4efac4b3645af059e6d6b9", null ],
    [ "w_ChirpCount", "structT__RL__API__SENSOR__STATUS__RSP.html#aba32d00a23360642740a37aa3ed42c20", null ],
    [ "w_FramePeriodTimerVal", "structT__RL__API__SENSOR__STATUS__RSP.html#a305924bb1b5c1715948154e6de722c03", null ],
    [ "w_FrameRefTimerVal", "structT__RL__API__SENSOR__STATUS__RSP.html#aeb0ea83f65d66b79e62a39cb59e6a614", null ],
    [ "w_Reserved3", "structT__RL__API__SENSOR__STATUS__RSP.html#aac7a4be7bbd9316a4d3ce32a1728c70a", null ]
];