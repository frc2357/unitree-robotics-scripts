var unionU__CT__PERCHIRP__IDLE__TIME__REP__CNT =
[
    [ "b16_Padfield_0", "unionU__CT__PERCHIRP__IDLE__TIME__REP__CNT.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b16_PerchirpIdleTimeRepCnt", "unionU__CT__PERCHIRP__IDLE__TIME__REP__CNT.html#a5f4644091313329410b73d9e9262586a", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__IDLE__TIME__REP__CNT.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__IDLE__TIME__REP__CNT.html#af32b6d772ada4b2fdd0f0c0570c3f51c", null ]
];