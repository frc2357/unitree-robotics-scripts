var structT__RL__API__SENS__DYN__PWR__SAVE__DIS =
[
    [ "c_InterChirpPsDis", "structT__RL__API__SENS__DYN__PWR__SAVE__DIS.html#a97623d1d7b5abc88f00d2e02741d38a3", null ],
    [ "c_Reserved", "structT__RL__API__SENS__DYN__PWR__SAVE__DIS.html#a8cb7e44eb1c3f29be371c2ab8ab20d6b", null ],
    [ "h_Reserved", "structT__RL__API__SENS__DYN__PWR__SAVE__DIS.html#a436c18d6c95b28eb31b9599e63209aa1", null ],
    [ "w_Reserved1", "structT__RL__API__SENS__DYN__PWR__SAVE__DIS.html#a94b7e367d00db535542e6e8c74eeb78a", null ]
];