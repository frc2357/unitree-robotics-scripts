var structT__RL__API__MON__TXN__POWER__RESULT =
[
    [ "h_Reserved1", "structT__RL__API__MON__TXN__POWER__RESULT.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "h_Reserved2", "structT__RL__API__MON__TXN__POWER__RESULT.html#af6916cc7db5fbc2060e7cfe6bf4c12a9", null ],
    [ "w_FrameCount", "structT__RL__API__MON__TXN__POWER__RESULT.html#a4186c07ac82a66607babd235976572cd", null ],
    [ "w_Reserved3", "structT__RL__API__MON__TXN__POWER__RESULT.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ],
    [ "xh_ErrorCode", "structT__RL__API__MON__TXN__POWER__RESULT.html#ad9a48e22c424c7ee64557d99729e6b46", null ],
    [ "xh_TxNPwrVal", "structT__RL__API__MON__TXN__POWER__RESULT.html#ab00278b428094dc380421d025b2d2873", null ]
];