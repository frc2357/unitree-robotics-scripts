var unionU__CT__N__STARTSLOPE__PULSE__OVERRIDE__MUX__SEL =
[
    [ "b1_NStartslopePulseOverrideMuxSel", "unionU__CT__N__STARTSLOPE__PULSE__OVERRIDE__MUX__SEL.html#ad9d4f031e47bf5f6759c8c5cc7c9b99c", null ],
    [ "b31_Padfield_0", "unionU__CT__N__STARTSLOPE__PULSE__OVERRIDE__MUX__SEL.html#a6a5501d56627cdd1079325301aa09d14", null ],
    [ "b32_Reg", "unionU__CT__N__STARTSLOPE__PULSE__OVERRIDE__MUX__SEL.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__N__STARTSLOPE__PULSE__OVERRIDE__MUX__SEL.html#aa31ad15c4e2688adf5c591dab51c9bb7", null ]
];