var unionU__CT__PERCHIRP__PARAMETER__EN =
[
    [ "b1_PerchirpAdcStartTimeEn", "unionU__CT__PERCHIRP__PARAMETER__EN.html#aa337424d5d12d746c32d048260b72295", null ],
    [ "b1_PerchirpFreqSlopeEn", "unionU__CT__PERCHIRP__PARAMETER__EN.html#a32fe807712c05e1f454f0ed334e95d61", null ],
    [ "b1_PerchirpFreqStartEn", "unionU__CT__PERCHIRP__PARAMETER__EN.html#a4c5430d9921940b9ade9c92f42e3476f", null ],
    [ "b1_PerchirpIdleTimeEn", "unionU__CT__PERCHIRP__PARAMETER__EN.html#a794ffa5785a805f81d694939577d4136", null ],
    [ "b1_PerchirpTxBpmEn", "unionU__CT__PERCHIRP__PARAMETER__EN.html#a3a09e7db1abf0c355d506a182a5fd79d", null ],
    [ "b1_PerchirpTxEnEn", "unionU__CT__PERCHIRP__PARAMETER__EN.html#a367ad558268a8b3db63918d74317c307", null ],
    [ "b1_PerchirpTxStartTimeEn", "unionU__CT__PERCHIRP__PARAMETER__EN.html#a025b2c28e61f78d05e3424c1149467ff", null ],
    [ "b25_Padfield_0", "unionU__CT__PERCHIRP__PARAMETER__EN.html#a4054dfe3480d2d26f1996b52e7c862e7", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__PARAMETER__EN.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__PARAMETER__EN.html#a9fec0d41d4f82b3992de2df8c3b7964c", null ]
];