var unionU__CT__HW__SPARE__REG4 =
[
    [ "b32_HwSpareReg4", "unionU__CT__HW__SPARE__REG4.html#aa5d578fb77296e68b2bb931992fac0d1", null ],
    [ "b32_Reg", "unionU__CT__HW__SPARE__REG4.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__HW__SPARE__REG4.html#a344ee8ad564a5a27789f73e5a602d5c9", null ]
];