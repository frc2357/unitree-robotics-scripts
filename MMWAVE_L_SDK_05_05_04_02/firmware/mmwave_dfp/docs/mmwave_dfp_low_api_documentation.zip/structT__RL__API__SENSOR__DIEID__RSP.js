var structT__RL__API__SENSOR__DIEID__RSP =
[
    [ "Reserved", "structT__RL__API__SENSOR__DIEID__RSP.html#aa961668998110952a13a82b87cceb443", null ],
    [ "w_DieIdData", "structT__RL__API__SENSOR__DIEID__RSP.html#aa51332622cc7241c0f9db3b51af89ce2", null ]
];