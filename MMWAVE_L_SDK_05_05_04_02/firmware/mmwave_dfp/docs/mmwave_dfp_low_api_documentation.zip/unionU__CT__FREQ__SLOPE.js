var unionU__CT__FREQ__SLOPE =
[
    [ "b16_FreqSlope", "unionU__CT__FREQ__SLOPE.html#a659203e041c337a410a83e18f64bed01", null ],
    [ "b16_Padfield_0", "unionU__CT__FREQ__SLOPE.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b32_Reg", "unionU__CT__FREQ__SLOPE.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__FREQ__SLOPE.html#af338ee4633252387d107eb0cc32307f4", null ]
];