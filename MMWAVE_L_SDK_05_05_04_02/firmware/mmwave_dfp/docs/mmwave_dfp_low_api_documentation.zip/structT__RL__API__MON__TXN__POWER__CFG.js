var structT__RL__API__MON__TXN__POWER__CFG =
[
    [ "c_MonTxCodesSel", "structT__RL__API__MON__TXN__POWER__CFG.html#a71ae817177725d417a0629c09dae679f", null ],
    [ "c_Reserved1", "structT__RL__API__MON__TXN__POWER__CFG.html#ad96962542b1b0b9bbad845921adee9b0", null ],
    [ "c_TxBackoffMap", "structT__RL__API__MON__TXN__POWER__CFG.html#a210be9afab7a0c4ab5f26096108483fc", null ],
    [ "c_TxIndSel", "structT__RL__API__MON__TXN__POWER__CFG.html#af932c157a6fe165ba022bc0b6cea635a", null ],
    [ "h_MonTxBiasCodes", "structT__RL__API__MON__TXN__POWER__CFG.html#a30e15a09e638d42afe5d48c1ac6fc35c", null ],
    [ "h_Reserved2", "structT__RL__API__MON__TXN__POWER__CFG.html#af6916cc7db5fbc2060e7cfe6bf4c12a9", null ],
    [ "h_RfFreqStart", "structT__RL__API__MON__TXN__POWER__CFG.html#ad498a6e150cfdc2499d08e74bdd3b346", null ],
    [ "w_Reserved3", "structT__RL__API__MON__TXN__POWER__CFG.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ],
    [ "xh_RfFreqSlope", "structT__RL__API__MON__TXN__POWER__CFG.html#a672b33c2257b50752246a5b7195e154f", null ]
];