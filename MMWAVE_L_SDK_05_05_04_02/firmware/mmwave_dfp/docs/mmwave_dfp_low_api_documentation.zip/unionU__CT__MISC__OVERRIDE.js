var unionU__CT__MISC__OVERRIDE =
[
    [ "b1_AdcAnaEnRxallOverride", "unionU__CT__MISC__OVERRIDE.html#a085e1336c2ac1b5af1abb6b06c9aff32", null ],
    [ "b1_AdcAnaEnRxallOverrideSel", "unionU__CT__MISC__OVERRIDE.html#a8ddc5d7523981c37a07dbc5f3d9c3240", null ],
    [ "b1_AdcIntRstzRxallOverride", "unionU__CT__MISC__OVERRIDE.html#ac91cd12ee49b7ff3dda5855b6025fdfe", null ],
    [ "b1_AdcIntRstzRxallOverrideSel", "unionU__CT__MISC__OVERRIDE.html#a1c5e02ea650955646ad7ce9d7aa03de9", null ],
    [ "b1_ResetSoccOverride", "unionU__CT__MISC__OVERRIDE.html#a3f963f5b80db77f9ed4d721e47068ab9", null ],
    [ "b1_ResetSoccOverrideSel", "unionU__CT__MISC__OVERRIDE.html#abce7b08732bca3dd54b89848d21396c0", null ],
    [ "b1_RxDfeResetOverride", "unionU__CT__MISC__OVERRIDE.html#ac37a54c19eb0f6e12305f74527cfd81e", null ],
    [ "b1_RxDfeResetOverrideSel", "unionU__CT__MISC__OVERRIDE.html#ae395a768e49005e618c7aaf73bbe2d09", null ],
    [ "b1_RxHpfFastInitOverride", "unionU__CT__MISC__OVERRIDE.html#ab8bf506caf7e1309197ba38a392666e5", null ],
    [ "b1_RxHpfFastInitOverrideSel", "unionU__CT__MISC__OVERRIDE.html#a23a13420fb9f78d5209d6ee0c14bafb9", null ],
    [ "b32_Reg", "unionU__CT__MISC__OVERRIDE.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b3_SynthFastResetEnOverride", "unionU__CT__MISC__OVERRIDE.html#a214ac9932dfb8233c1882e5f7f282442", null ],
    [ "b3_SynthFastResetEnOverrideSel", "unionU__CT__MISC__OVERRIDE.html#a30f73b10bc20dc842a5b82b251510a65", null ],
    [ "b4_TxBpmOverride", "unionU__CT__MISC__OVERRIDE.html#aeaa46e5681dfeb260588ab814a95cb32", null ],
    [ "b4_TxBpmOverrideSel", "unionU__CT__MISC__OVERRIDE.html#aff148fcab71a684b9dc14eefc5fcd31d", null ],
    [ "b8_Padfield_0", "unionU__CT__MISC__OVERRIDE.html#a69b308cc2c42c40c7788924b4aae5c55", null ],
    [ "bits", "unionU__CT__MISC__OVERRIDE.html#ad5a198d0f189297cf8dbe8a7fc8a503b", null ]
];