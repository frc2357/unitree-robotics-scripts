var unionU__CT__RAPID__EN__LO__TX__END__TIME__REG =
[
    [ "b32_Reg", "unionU__CT__RAPID__EN__LO__TX__END__TIME__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_RapidEnLoTx1EndTime", "unionU__CT__RAPID__EN__LO__TX__END__TIME__REG.html#ac424a49401f91db612c414d972e83708", null ],
    [ "b8_RapidEnLoTx2EndTime", "unionU__CT__RAPID__EN__LO__TX__END__TIME__REG.html#a56cddbeb9b5be88b97b02192a54bd84d", null ],
    [ "b8_RapidEnLoTx3EndTime", "unionU__CT__RAPID__EN__LO__TX__END__TIME__REG.html#a0782f06fc03705fcff0fa80af52fed81", null ],
    [ "b8_RapidEnLoTx4EndTime", "unionU__CT__RAPID__EN__LO__TX__END__TIME__REG.html#a2d20a5cc72bfc8355a70f17b8914d671", null ],
    [ "bits", "unionU__CT__RAPID__EN__LO__TX__END__TIME__REG.html#a2373f51f0f59fbf9f10e5d841f7a98f2", null ]
];