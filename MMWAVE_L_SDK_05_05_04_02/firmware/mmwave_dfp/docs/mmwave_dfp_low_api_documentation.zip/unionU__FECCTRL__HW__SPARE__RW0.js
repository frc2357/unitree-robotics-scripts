var unionU__FECCTRL__HW__SPARE__RW0 =
[
    [ "b32_HwSpareRw0", "unionU__FECCTRL__HW__SPARE__RW0.html#a1e89d6c13455ba67279e34ce8b8c82ef", null ],
    [ "b32_Reg", "unionU__FECCTRL__HW__SPARE__RW0.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__FECCTRL__HW__SPARE__RW0.html#aecc2433d25e6a79e26190c42041adda1", null ]
];