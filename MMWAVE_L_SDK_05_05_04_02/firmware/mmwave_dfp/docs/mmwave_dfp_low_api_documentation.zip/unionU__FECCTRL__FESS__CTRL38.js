var unionU__FECCTRL__FESS__CTRL38 =
[
    [ "b1_FessCtrl38", "unionU__FECCTRL__FESS__CTRL38.html#a36e9068231050c79ff5174f4b9081209", null ],
    [ "b31_Padfield_0", "unionU__FECCTRL__FESS__CTRL38.html#a6a5501d56627cdd1079325301aa09d14", null ],
    [ "b32_Reg", "unionU__FECCTRL__FESS__CTRL38.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__FECCTRL__FESS__CTRL38.html#abc9ed488b5181bc72ddf487fbc31fc2c", null ]
];