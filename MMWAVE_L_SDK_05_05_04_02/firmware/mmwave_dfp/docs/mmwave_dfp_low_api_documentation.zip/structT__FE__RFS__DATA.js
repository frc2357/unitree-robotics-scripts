var structT__FE__RFS__DATA =
[
    [ "c_BootStatus", "structT__FE__RFS__DATA.html#af334b4b742e318c2ee7b4c643d832a22", null ],
    [ "c_MbStatus", "structT__FE__RFS__DATA.html#a16105f2701988c42dc625a480841235f", null ],
    [ "c_Reserved", "structT__FE__RFS__DATA.html#a8cb7e44eb1c3f29be371c2ab8ab20d6b", null ],
    [ "c_RfsRespSemaSigFail", "structT__FE__RFS__DATA.html#a5af52e40005ecce4842802b33c35006f", null ],
    [ "h_MbLastCmd", "structT__FE__RFS__DATA.html#ab7bc6d35b7ca092f33bb51f47c9afae6", null ],
    [ "h_MbLastRes", "structT__FE__RFS__DATA.html#a81101780b948b815f0d1bb54348bdb21", null ],
    [ "w_BootTime", "structT__FE__RFS__DATA.html#ad9d87b0a0bc1351eaf70298dc7b20939", null ]
];