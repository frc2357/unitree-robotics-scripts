var unionU__FECCTRL__FECSS__GPADC__MEM__INIT =
[
    [ "b1_MemInit", "unionU__FECCTRL__FECSS__GPADC__MEM__INIT.html#a36fad4176824d2bc7d080743c4d43d0b", null ],
    [ "b31_Padfield_0", "unionU__FECCTRL__FECSS__GPADC__MEM__INIT.html#a6a5501d56627cdd1079325301aa09d14", null ],
    [ "b32_Reg", "unionU__FECCTRL__FECSS__GPADC__MEM__INIT.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__FECCTRL__FECSS__GPADC__MEM__INIT.html#afb4b16d372f726a0da252c5eab293d8b", null ]
];