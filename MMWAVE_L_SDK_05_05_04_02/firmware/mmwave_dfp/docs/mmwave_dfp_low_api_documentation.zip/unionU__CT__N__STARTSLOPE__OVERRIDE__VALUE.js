var unionU__CT__N__STARTSLOPE__OVERRIDE__VALUE =
[
    [ "b1_NStartslopeOverrideValue", "unionU__CT__N__STARTSLOPE__OVERRIDE__VALUE.html#a399e3a2959a45335eb130b0d3689fb3e", null ],
    [ "b31_Padfield_0", "unionU__CT__N__STARTSLOPE__OVERRIDE__VALUE.html#a6a5501d56627cdd1079325301aa09d14", null ],
    [ "b32_Reg", "unionU__CT__N__STARTSLOPE__OVERRIDE__VALUE.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__N__STARTSLOPE__OVERRIDE__VALUE.html#ab21d74b6ee8c56a91761bb42f294e63d", null ]
];