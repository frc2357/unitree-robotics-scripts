var structT__FE__SENS__CT__COMN__PROFILE =
[
    [ "c_ChirpTxMimoPatSel", "structT__FE__SENS__CT__COMN__PROFILE.html#a2442fbe8da8b46e5510435739a0712c4", null ],
    [ "c_HpfFastInitDuration", "structT__FE__SENS__CT__COMN__PROFILE.html#ad3007bacc0780a40a19641ccf7682120", null ],
    [ "c_MiscSettings", "structT__FE__SENS__CT__COMN__PROFILE.html#ace809afb70e3701f8bed0956b285e525", null ],
    [ "c_Reserved1", "structT__FE__SENS__CT__COMN__PROFILE.html#ad96962542b1b0b9bbad845921adee9b0", null ],
    [ "h_ChirpRampEndTime", "structT__FE__SENS__CT__COMN__PROFILE.html#ad68c076101aafc497a14cc5099ce1d67", null ],
    [ "h_CrdNSlopeMag", "structT__FE__SENS__CT__COMN__PROFILE.html#a560451e5e4528fa2358923810d2fd91f", null ]
];