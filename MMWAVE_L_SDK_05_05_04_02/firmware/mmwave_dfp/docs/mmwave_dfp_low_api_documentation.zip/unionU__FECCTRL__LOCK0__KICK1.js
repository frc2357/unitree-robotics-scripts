var unionU__FECCTRL__LOCK0__KICK1 =
[
    [ "b32_Reg", "unionU__FECCTRL__LOCK0__KICK1.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b32_Value", "unionU__FECCTRL__LOCK0__KICK1.html#a455f75cc0afd22fcfd63f1be0339b02f", null ],
    [ "bits", "unionU__FECCTRL__LOCK0__KICK1.html#a9e45f59732706b83757a3331b0294c45", null ]
];