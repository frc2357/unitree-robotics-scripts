var structT__SENS__PER__CHIRP__LUT =
[
    [ "c_ChirpBpmEn", "structT__SENS__PER__CHIRP__LUT.html#adc3c3a054c322a869a7ac16245c37ecc", null ],
    [ "c_ChirpTxEn", "structT__SENS__PER__CHIRP__LUT.html#a8e23b90c4868625da391cde5c63b2ce2", null ],
    [ "h_ChirpAdcStartTime", "structT__SENS__PER__CHIRP__LUT.html#a48fb6b40c0b7565aebb6d4256a8e10f8", null ],
    [ "h_ChirpIdleTime", "structT__SENS__PER__CHIRP__LUT.html#af6c187870b2fd41764947d93e24f6c03", null ],
    [ "w_StartFreqHighRes", "structT__SENS__PER__CHIRP__LUT.html#affc852202388e11f15d9321bcf9798a1", null ],
    [ "xh_ChirpSlope", "structT__SENS__PER__CHIRP__LUT.html#ae63b7acd6d4c4f21dc0b30c9207ba31a", null ],
    [ "xh_ChirpTxStartTime", "structT__SENS__PER__CHIRP__LUT.html#adf92db6b5bfa217b6899c16c3eadfee5", null ]
];