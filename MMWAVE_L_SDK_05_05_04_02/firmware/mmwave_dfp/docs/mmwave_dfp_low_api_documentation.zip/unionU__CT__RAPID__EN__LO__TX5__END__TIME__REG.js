var unionU__CT__RAPID__EN__LO__TX5__END__TIME__REG =
[
    [ "b32_Reg", "unionU__CT__RAPID__EN__LO__TX5__END__TIME__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_RapidEnLoTx5EndTime", "unionU__CT__RAPID__EN__LO__TX5__END__TIME__REG.html#ad91eab5a6d03a08ca798670760f81132", null ],
    [ "b8_RapidEnLoTx6EndTime", "unionU__CT__RAPID__EN__LO__TX5__END__TIME__REG.html#a89c2ca3df0f14656496edcf07521c667", null ],
    [ "b8_RapidEnLoTx7EndTime", "unionU__CT__RAPID__EN__LO__TX5__END__TIME__REG.html#aca9ac65b99a4e63891c90696de6fb33a", null ],
    [ "b8_RapidEnLoTx8EndTime", "unionU__CT__RAPID__EN__LO__TX5__END__TIME__REG.html#a2435715be21396cc1db9d0d376f71645", null ],
    [ "bits", "unionU__CT__RAPID__EN__LO__TX5__END__TIME__REG.html#affab88ca029a1e1396f05859c9284f54", null ]
];