var unionU__CT__BURST__START__OFFSET__TIME =
[
    [ "b16_BurstStartOffsetTime", "unionU__CT__BURST__START__OFFSET__TIME.html#a48755c6e993f7f27839d5e46fed1a3ac", null ],
    [ "b16_Padfield_0", "unionU__CT__BURST__START__OFFSET__TIME.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b32_Reg", "unionU__CT__BURST__START__OFFSET__TIME.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__BURST__START__OFFSET__TIME.html#a3752834f6541b14ffe13c9e639f444a1", null ]
];