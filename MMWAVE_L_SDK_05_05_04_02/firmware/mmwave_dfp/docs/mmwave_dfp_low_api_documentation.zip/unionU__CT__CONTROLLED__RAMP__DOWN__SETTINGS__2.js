var unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__2 =
[
    [ "b10_CrdFreqOffsetTime", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__2.html#ae533b61ec3538e7afaabf8d8b00cc78d", null ],
    [ "b15_CrdNslopeMag", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__2.html#a7e23d4200f13fc38f55d22edbf953a1d", null ],
    [ "b1_Padfield_0", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__2.html#a52971a89fa014b5e6a9339583402d9ba", null ],
    [ "b32_Reg", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__2.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b6_Padfield_1", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__2.html#afd7dbbdca0aeebc22867a6cfce6c5fce", null ],
    [ "bits", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__2.html#a9851c0dc7484f0fce87bbc951f6e369c", null ]
];