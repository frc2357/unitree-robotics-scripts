var structT__FE__SENS__FT__FRAME__CFG =
[
    [ "h_NumOfFrames", "structT__FE__SENS__FT__FRAME__CFG.html#ad99768385c4f7be27bf93db5519ce13d", null ],
    [ "h_Reserved2", "structT__FE__SENS__FT__FRAME__CFG.html#af6916cc7db5fbc2060e7cfe6bf4c12a9", null ],
    [ "w_FrameEvent0TimeCfg", "structT__FE__SENS__FT__FRAME__CFG.html#a0a15595781fd15c880bd454bfef50700", null ],
    [ "w_FrameEvent1TimeCfg", "structT__FE__SENS__FT__FRAME__CFG.html#a90e85cb0fa63a89461d44469c096c5fb", null ],
    [ "w_FramePeriodicity", "structT__FE__SENS__FT__FRAME__CFG.html#ab2a104688c74435a4f7265fdce17fc49", null ]
];