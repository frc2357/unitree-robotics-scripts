var structT__RL__API__MON__DBG__PD__MEAS__CMD =
[
    [ "c_PdId", "structT__RL__API__MON__DBG__PD__MEAS__CMD.html#a0ea7cc4425ae5e2e0726aedf6e4ff096", null ],
    [ "c_PdLnaGainIndx", "structT__RL__API__MON__DBG__PD__MEAS__CMD.html#a9e02e918c2d79af875535d1785e92375", null ],
    [ "c_PdLnaIndx", "structT__RL__API__MON__DBG__PD__MEAS__CMD.html#a274fc97b7855db03fe3333c5e56db286", null ],
    [ "c_PdLnaOffsetDacVal", "structT__RL__API__MON__DBG__PD__MEAS__CMD.html#aaa6352dd887f031769a655198e3d6154", null ],
    [ "c_PdNAccum", "structT__RL__API__MON__DBG__PD__MEAS__CMD.html#a6e103cd8e05dd0abf15a574d06005a37", null ],
    [ "c_PdNSamples", "structT__RL__API__MON__DBG__PD__MEAS__CMD.html#ae979e5dfd615fc5e059c49e51c5c7861", null ],
    [ "c_PdSelect", "structT__RL__API__MON__DBG__PD__MEAS__CMD.html#a7ac501277b3bc5a15b423cf105511834", null ],
    [ "c_PdType", "structT__RL__API__MON__DBG__PD__MEAS__CMD.html#ad8cfb5d927901afff3241f9ae1f2f0b8", null ],
    [ "w_Reserved1", "structT__RL__API__MON__DBG__PD__MEAS__CMD.html#a94b7e367d00db535542e6e8c74eeb78a", null ],
    [ "w_Reserved2", "structT__RL__API__MON__DBG__PD__MEAS__CMD.html#adad85885669e932d55697b63bec2a941", null ]
];