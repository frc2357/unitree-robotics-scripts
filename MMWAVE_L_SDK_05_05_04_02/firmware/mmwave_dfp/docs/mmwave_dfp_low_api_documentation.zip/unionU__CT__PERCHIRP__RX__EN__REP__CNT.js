var unionU__CT__PERCHIRP__RX__EN__REP__CNT =
[
    [ "b16_Padfield_0", "unionU__CT__PERCHIRP__RX__EN__REP__CNT.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b16_PerchirpRxEnRepCnt", "unionU__CT__PERCHIRP__RX__EN__REP__CNT.html#a467db1ac48de9c04170747b4d7914594", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__RX__EN__REP__CNT.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__RX__EN__REP__CNT.html#a488bda19f4bc5a548e760a88accc8ead", null ]
];