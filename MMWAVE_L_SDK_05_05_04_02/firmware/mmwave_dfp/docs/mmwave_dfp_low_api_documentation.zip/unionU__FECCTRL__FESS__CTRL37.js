var unionU__FECCTRL__FESS__CTRL37 =
[
    [ "b32_FessCtrl37", "unionU__FECCTRL__FESS__CTRL37.html#ae0844103dd3cc3dcacd121821390899a", null ],
    [ "b32_Reg", "unionU__FECCTRL__FESS__CTRL37.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__FECCTRL__FESS__CTRL37.html#ad1c9ecbc7e09508ac25f6069cf0e4312", null ]
];