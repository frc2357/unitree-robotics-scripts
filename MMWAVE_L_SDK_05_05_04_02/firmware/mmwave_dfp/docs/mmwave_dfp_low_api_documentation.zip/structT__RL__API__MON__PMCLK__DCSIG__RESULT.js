var structT__RL__API__MON__PMCLK__DCSIG__RESULT =
[
    [ "c_VRef1Val", "structT__RL__API__MON__PMCLK__DCSIG__RESULT.html#a99aaa08d856f64509cee662e7669c62f", null ],
    [ "c_VRef2Val", "structT__RL__API__MON__PMCLK__DCSIG__RESULT.html#a37d5d3652c123b326efb9268e971d179", null ],
    [ "c_VRef3Val", "structT__RL__API__MON__PMCLK__DCSIG__RESULT.html#a1144e34e1bfea20ab5ec8a199738bd01", null ],
    [ "c_VRef4Val", "structT__RL__API__MON__PMCLK__DCSIG__RESULT.html#ac42d7b616b26a160684452371247925c", null ],
    [ "h_Reserved1", "structT__RL__API__MON__PMCLK__DCSIG__RESULT.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "w_FrameCount", "structT__RL__API__MON__PMCLK__DCSIG__RESULT.html#a4186c07ac82a66607babd235976572cd", null ],
    [ "w_PmClkDcMonStatus", "structT__RL__API__MON__PMCLK__DCSIG__RESULT.html#a938a8e4ef7bfe7e83f03f348bab722d2", null ],
    [ "w_Reserved2", "structT__RL__API__MON__PMCLK__DCSIG__RESULT.html#adad85885669e932d55697b63bec2a941", null ],
    [ "w_Reserved3", "structT__RL__API__MON__PMCLK__DCSIG__RESULT.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ],
    [ "xh_ErrorCode", "structT__RL__API__MON__PMCLK__DCSIG__RESULT.html#ad9a48e22c424c7ee64557d99729e6b46", null ]
];