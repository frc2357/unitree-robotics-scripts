var unionU__CT__MISC__RO__REGS =
[
    [ "b32_NextChirpStartFreqRo", "unionU__CT__MISC__RO__REGS.html#ae48d00abf6e7f0143f0a8cbd5a7c17c2", null ],
    [ "b32_Reg", "unionU__CT__MISC__RO__REGS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__MISC__RO__REGS.html#a8a83646ec6ea9f701427c00fd95be723", null ]
];