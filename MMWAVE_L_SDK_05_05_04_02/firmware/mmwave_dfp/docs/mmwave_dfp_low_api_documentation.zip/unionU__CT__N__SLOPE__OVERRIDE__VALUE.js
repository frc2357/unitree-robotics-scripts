var unionU__CT__N__SLOPE__OVERRIDE__VALUE =
[
    [ "b10_Padfield_0", "unionU__CT__N__SLOPE__OVERRIDE__VALUE.html#aeaa350afea07e49146b97f703e61ccad", null ],
    [ "b22_NSlopeOverrideValue", "unionU__CT__N__SLOPE__OVERRIDE__VALUE.html#ac8c65beb1312bc18742f08304560b7fb", null ],
    [ "b32_Reg", "unionU__CT__N__SLOPE__OVERRIDE__VALUE.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__N__SLOPE__OVERRIDE__VALUE.html#a8710f41cb3613666ca86af2d4c13c008", null ]
];