var structT__FE__API__RFS__CW__SENSOR__STOP__CMD =
[
    [ "c_Reserved", "structT__FE__API__RFS__CW__SENSOR__STOP__CMD.html#a8cb7e44eb1c3f29be371c2ab8ab20d6b", null ],
    [ "c_SensorStopMode", "structT__FE__API__RFS__CW__SENSOR__STOP__CMD.html#a96835e910372fe514a0199272b948e26", null ],
    [ "h_Reserved1", "structT__FE__API__RFS__CW__SENSOR__STOP__CMD.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "w_Reserved2", "structT__FE__API__RFS__CW__SENSOR__STOP__CMD.html#adad85885669e932d55697b63bec2a941", null ]
];