var structT__RL__API__MON__PLL__CTRL__VOLT__RESULT =
[
    [ "h_ApllCtrlVolt", "structT__RL__API__MON__PLL__CTRL__VOLT__RESULT.html#a0385496da60772a88b80fce83cc99864", null ],
    [ "h_Reserved1", "structT__RL__API__MON__PLL__CTRL__VOLT__RESULT.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "h_Reserved2", "structT__RL__API__MON__PLL__CTRL__VOLT__RESULT.html#af6916cc7db5fbc2060e7cfe6bf4c12a9", null ],
    [ "h_SynthMaxCtrlVolt", "structT__RL__API__MON__PLL__CTRL__VOLT__RESULT.html#a0a61d9ef7e7efad011595a405fc8b52b", null ],
    [ "h_SynthMinCtrlVolt", "structT__RL__API__MON__PLL__CTRL__VOLT__RESULT.html#a3df661759c781b818be26a419fc8862c", null ],
    [ "w_FrameCount", "structT__RL__API__MON__PLL__CTRL__VOLT__RESULT.html#a4186c07ac82a66607babd235976572cd", null ],
    [ "w_Reserved3", "structT__RL__API__MON__PLL__CTRL__VOLT__RESULT.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ],
    [ "w_Reserved4", "structT__RL__API__MON__PLL__CTRL__VOLT__RESULT.html#a9fdf5cd48e45afcc69617cf33021ac93", null ],
    [ "w_Reserved5", "structT__RL__API__MON__PLL__CTRL__VOLT__RESULT.html#a2281d5eb7984d88bc7ebaca20319a467", null ],
    [ "xh_ErrorCode", "structT__RL__API__MON__PLL__CTRL__VOLT__RESULT.html#ad9a48e22c424c7ee64557d99729e6b46", null ]
];