var unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__3 =
[
    [ "b16_CrdMaxFreqOffsetDither", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__3.html#af68e4ea108e0c4b468f2fe567d7f13f2", null ],
    [ "b16_Padfield_0", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__3.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b32_Reg", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__3.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__3.html#a79919854e0cf87394555469da29dac2a", null ]
];