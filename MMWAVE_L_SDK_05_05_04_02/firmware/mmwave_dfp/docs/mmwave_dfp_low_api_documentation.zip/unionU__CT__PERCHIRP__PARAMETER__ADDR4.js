var unionU__CT__PERCHIRP__PARAMETER__ADDR4 =
[
    [ "b16_PerchirpSatIndicationAddr", "unionU__CT__PERCHIRP__PARAMETER__ADDR4.html#a79613cd9ec43e90c4098386004f80eab", null ],
    [ "b16_PerchirpTxBpmAddr", "unionU__CT__PERCHIRP__PARAMETER__ADDR4.html#a4e922bac5a89f8c20770561eb62289c2", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__PARAMETER__ADDR4.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__PARAMETER__ADDR4.html#af9dd454f6c6ce713c55511a1dba0a55c", null ]
];