var unionU__CT__RAPID__EN__BB__RX__START__TIME__REG =
[
    [ "b32_Reg", "unionU__CT__RAPID__EN__BB__RX__START__TIME__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_RapidEnBbRx1StartTime", "unionU__CT__RAPID__EN__BB__RX__START__TIME__REG.html#a87687540f8a242855662acb436a5b7dd", null ],
    [ "b8_RapidEnBbRx2StartTime", "unionU__CT__RAPID__EN__BB__RX__START__TIME__REG.html#af23e5073c5d1cf598561b646a7a2257a", null ],
    [ "b8_RapidEnBbRx3StartTime", "unionU__CT__RAPID__EN__BB__RX__START__TIME__REG.html#acc2ca257579706cbdc588a76dc4533f7", null ],
    [ "b8_RapidEnBbRx4StartTime", "unionU__CT__RAPID__EN__BB__RX__START__TIME__REG.html#a2d040674e29b9d2b6f2a8162ff73677d", null ],
    [ "bits", "unionU__CT__RAPID__EN__BB__RX__START__TIME__REG.html#ad0c0b5d315d12dd3069833b4d374d197", null ]
];