var unionU__FECCTRL__FAULT__ADDRESS =
[
    [ "b32_FaultAddr", "unionU__FECCTRL__FAULT__ADDRESS.html#a018fe8712e6d9b6fd1ee5c7e5321bfeb", null ],
    [ "b32_Reg", "unionU__FECCTRL__FAULT__ADDRESS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__FECCTRL__FAULT__ADDRESS.html#a319c95034f89583bb782037a84954d24", null ]
];