var unionU__CT__AFE__POWER__SAVE__EN__REG =
[
    [ "b1_AfePowerSaveEnBbRx", "unionU__CT__AFE__POWER__SAVE__EN__REG.html#a9c2bb74658b23294278f6d572d0ee645", null ],
    [ "b1_AfePowerSaveEnLoRx", "unionU__CT__AFE__POWER__SAVE__EN__REG.html#a84b71d9983a05e2d217d4bca81b15c6f", null ],
    [ "b1_AfePowerSaveEnLoTx", "unionU__CT__AFE__POWER__SAVE__EN__REG.html#af1c219cb9f7082acbc88c36968524148", null ],
    [ "b1_AfePowerSaveEnPaTx", "unionU__CT__AFE__POWER__SAVE__EN__REG.html#a4566d65c945848b4d5efb137de1dc324", null ],
    [ "b1_AfePowerSaveEnRfRx", "unionU__CT__AFE__POWER__SAVE__EN__REG.html#abc2bdadb57ccbf54c22e919a970b559a", null ],
    [ "b1_InterburstAfePowerSaveEnBbRx", "unionU__CT__AFE__POWER__SAVE__EN__REG.html#a0d0e757003f93eca5ca407b4fbd1b8cf", null ],
    [ "b1_InterburstAfePowerSaveEnLoRx", "unionU__CT__AFE__POWER__SAVE__EN__REG.html#aad7993c7f9c6591f16590b6feb7642c3", null ],
    [ "b1_InterburstAfePowerSaveEnLoTx", "unionU__CT__AFE__POWER__SAVE__EN__REG.html#a655fcec2a1d71418de4057bf3b0c8f76", null ],
    [ "b1_InterburstAfePowerSaveEnPaTx", "unionU__CT__AFE__POWER__SAVE__EN__REG.html#a9e75e0df2297abd903a2d337ea6fc8e5", null ],
    [ "b1_InterburstAfePowerSaveEnRfRx", "unionU__CT__AFE__POWER__SAVE__EN__REG.html#a24155c2c10e53370f88e8ebbc6707794", null ],
    [ "b22_Padfield_0", "unionU__CT__AFE__POWER__SAVE__EN__REG.html#a9946ee8b2936e456cf45a61bb6dda4c7", null ],
    [ "b32_Reg", "unionU__CT__AFE__POWER__SAVE__EN__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__AFE__POWER__SAVE__EN__REG.html#a2be4789d29c46780b045a6cef351e7be", null ]
];