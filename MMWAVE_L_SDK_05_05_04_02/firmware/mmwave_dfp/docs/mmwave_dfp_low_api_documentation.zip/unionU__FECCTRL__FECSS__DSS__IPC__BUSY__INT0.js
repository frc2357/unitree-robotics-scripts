var unionU__FECCTRL__FECSS__DSS__IPC__BUSY__INT0 =
[
    [ "b1_Flag", "unionU__FECCTRL__FECSS__DSS__IPC__BUSY__INT0.html#aefc0b0923b891a61d1734f65a219ad2c", null ],
    [ "b31_Padfield_0", "unionU__FECCTRL__FECSS__DSS__IPC__BUSY__INT0.html#a6a5501d56627cdd1079325301aa09d14", null ],
    [ "b32_Reg", "unionU__FECCTRL__FECSS__DSS__IPC__BUSY__INT0.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__FECCTRL__FECSS__DSS__IPC__BUSY__INT0.html#a7afd624a20441502611f1fc5ab0c0b90", null ]
];