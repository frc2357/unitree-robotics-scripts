var unionU__CT__PERCHIRP__PARAMETER__LEN4 =
[
    [ "b16_Padfield_0", "unionU__CT__PERCHIRP__PARAMETER__LEN4.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b16_PerchirpTxBpmLen", "unionU__CT__PERCHIRP__PARAMETER__LEN4.html#a95d3f59ff654c44e7638f51a9ea3128f", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__PARAMETER__LEN4.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__PARAMETER__LEN4.html#a763ec66b00efd5218f011437b52f633f", null ]
];