var unionU__FECCTRL__EOI =
[
    [ "b24_Padfield_0", "unionU__FECCTRL__EOI.html#a5eee3a45ed8ea134718d5c80b151fa5c", null ],
    [ "b32_Reg", "unionU__FECCTRL__EOI.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_Vector", "unionU__FECCTRL__EOI.html#a3a63728992dd1c16f3c70bac89277800", null ],
    [ "bits", "unionU__FECCTRL__EOI.html#ac4709be703e06c2ffad25ca57f273e24", null ]
];