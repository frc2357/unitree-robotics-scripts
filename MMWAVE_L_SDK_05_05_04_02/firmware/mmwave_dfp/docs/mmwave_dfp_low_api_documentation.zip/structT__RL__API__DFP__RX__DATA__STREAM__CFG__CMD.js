var structT__RL__API__DFP__RX__DATA__STREAM__CFG__CMD =
[
    [ "c_DitherEn", "structT__RL__API__DFP__RX__DATA__STREAM__CFG__CMD.html#a374aa25c3797bf6af614684a27786876", null ],
    [ "c_Reserved0", "structT__RL__API__DFP__RX__DATA__STREAM__CFG__CMD.html#a6e359a94ca4b7990d84c829a1183205b", null ],
    [ "c_SidebandDataEn", "structT__RL__API__DFP__RX__DATA__STREAM__CFG__CMD.html#af42bce5f4d853b9cfb190bb0af06d74a", null ],
    [ "c_StreamMode", "structT__RL__API__DFP__RX__DATA__STREAM__CFG__CMD.html#a3c6d9aa01469c41990715eb1eb639f5c", null ],
    [ "h_DitherDelayMax", "structT__RL__API__DFP__RX__DATA__STREAM__CFG__CMD.html#af639c95ff497db98b4d9d7f0503bdbc2", null ],
    [ "h_RxChanEnMask", "structT__RL__API__DFP__RX__DATA__STREAM__CFG__CMD.html#a59b973b08de6d4692c85b2c496cf4d21", null ],
    [ "w_Reserved", "structT__RL__API__DFP__RX__DATA__STREAM__CFG__CMD.html#a96856985895564689000d85fbbc3df89", null ]
];