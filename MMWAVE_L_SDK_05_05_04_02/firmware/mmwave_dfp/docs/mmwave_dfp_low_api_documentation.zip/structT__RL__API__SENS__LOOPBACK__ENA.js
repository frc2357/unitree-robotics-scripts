var structT__RL__API__SENS__LOOPBACK__ENA =
[
    [ "c_LbEnable", "structT__RL__API__SENS__LOOPBACK__ENA.html#ab92d3e1cca3b53487994941aa14ade92", null ],
    [ "c_Reserved1", "structT__RL__API__SENS__LOOPBACK__ENA.html#ad96962542b1b0b9bbad845921adee9b0", null ],
    [ "h_Reserved2", "structT__RL__API__SENS__LOOPBACK__ENA.html#af6916cc7db5fbc2060e7cfe6bf4c12a9", null ],
    [ "w_Reserved3", "structT__RL__API__SENS__LOOPBACK__ENA.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ]
];