var structT__RL__API__MON__TXN__DCSIG__RESULT =
[
    [ "h_TxDcMonStatus", "structT__RL__API__MON__TXN__DCSIG__RESULT.html#a271c6d661a868d4a2628e13e827bffe8", null ],
    [ "w_FrameCount", "structT__RL__API__MON__TXN__DCSIG__RESULT.html#a4186c07ac82a66607babd235976572cd", null ],
    [ "w_Reserved1", "structT__RL__API__MON__TXN__DCSIG__RESULT.html#a94b7e367d00db535542e6e8c74eeb78a", null ],
    [ "w_Reserved2", "structT__RL__API__MON__TXN__DCSIG__RESULT.html#adad85885669e932d55697b63bec2a941", null ],
    [ "xh_ErrorCode", "structT__RL__API__MON__TXN__DCSIG__RESULT.html#ad9a48e22c424c7ee64557d99729e6b46", null ]
];