var unionU__CT__SOCC__TIMING__REG =
[
    [ "b32_Reg", "unionU__CT__SOCC__TIMING__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_ResetSoccEndTime", "unionU__CT__SOCC__TIMING__REG.html#a8a787f4f97355e7fc30395a0b7a40833", null ],
    [ "b8_ResetSoccStartTime", "unionU__CT__SOCC__TIMING__REG.html#adbe139ec03401cbfd750b1e59e745ec8", null ],
    [ "b8_SoccTestClkEnEndTime", "unionU__CT__SOCC__TIMING__REG.html#a1e2af19ed91c2e73247b58676f36c5de", null ],
    [ "b8_SoccTestClkEnStartTime", "unionU__CT__SOCC__TIMING__REG.html#aab700c900afbffe1d8efa14008341495", null ],
    [ "bits", "unionU__CT__SOCC__TIMING__REG.html#a45521b5786363ed9d996f04692f08a0c", null ]
];