var unionU__CT__PA__BLANKING =
[
    [ "b1_EnDfePaBlanking", "unionU__CT__PA__BLANKING.html#a8db5dc1a12b7f899d5af5d794d3b46fc", null ],
    [ "b1_EnPaBlankingFeature", "unionU__CT__PA__BLANKING.html#a72e78d29702afc3abc469098be6a3d1b", null ],
    [ "b1_PaBlankingStatus", "unionU__CT__PA__BLANKING.html#a6d20da5142dfbde79e72979cfe726a76", null ],
    [ "b29_Padfield_0", "unionU__CT__PA__BLANKING.html#a1426169b681912d54e41a876cc66b5c7", null ],
    [ "b32_Reg", "unionU__CT__PA__BLANKING.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PA__BLANKING.html#a3392edbbcbb92b94fa3faed7de4f7834", null ]
];