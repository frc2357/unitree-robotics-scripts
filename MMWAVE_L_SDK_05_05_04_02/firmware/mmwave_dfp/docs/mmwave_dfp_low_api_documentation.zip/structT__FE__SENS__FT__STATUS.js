var structT__FE__SENS__FT__STATUS =
[
    [ "c_FrameStartStopStatus", "structT__FE__SENS__FT__STATUS.html#a6a60b1f9cc0dab56ad27840bcd8bc729", null ],
    [ "c_Reserved1", "structT__FE__SENS__FT__STATUS.html#ad96962542b1b0b9bbad845921adee9b0", null ],
    [ "h_FrameCount", "structT__FE__SENS__FT__STATUS.html#adbd8539eb56141cc86feb63a767ed1a0", null ],
    [ "w_FramePeriodTimerVal", "structT__FE__SENS__FT__STATUS.html#a305924bb1b5c1715948154e6de722c03", null ],
    [ "w_FrameRefTimerVal", "structT__FE__SENS__FT__STATUS.html#aeb0ea83f65d66b79e62a39cb59e6a614", null ]
];