var structT__RL__API__MON__RX__HPF__DCSIG__RESULT =
[
    [ "h_Reserved1", "structT__RL__API__MON__RX__HPF__DCSIG__RESULT.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "w_FrameCount", "structT__RL__API__MON__RX__HPF__DCSIG__RESULT.html#a4186c07ac82a66607babd235976572cd", null ],
    [ "w_Reserved2", "structT__RL__API__MON__RX__HPF__DCSIG__RESULT.html#adad85885669e932d55697b63bec2a941", null ],
    [ "w_Reserved3", "structT__RL__API__MON__RX__HPF__DCSIG__RESULT.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ],
    [ "w_RxDcMonStatus", "structT__RL__API__MON__RX__HPF__DCSIG__RESULT.html#ac80fbbda0cf9335aa6b1e809cd5b5539", null ],
    [ "xh_ErrorCode", "structT__RL__API__MON__RX__HPF__DCSIG__RESULT.html#ad9a48e22c424c7ee64557d99729e6b46", null ],
    [ "xh_RxHpfCutOffPwr", "structT__RL__API__MON__RX__HPF__DCSIG__RESULT.html#a656c1e8413e7d5bf97a52f99c3983400", null ],
    [ "xh_RxHpfInBandPwr", "structT__RL__API__MON__RX__HPF__DCSIG__RESULT.html#ab17d3b80be119b8093effc83b7eec18b", null ]
];