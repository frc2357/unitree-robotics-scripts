var structT__RL__API__SENS__PER__CHIRP__CFG =
[
    [ "h_ParamArrayLen", "structT__RL__API__SENS__PER__CHIRP__CFG.html#a2c140748a0a61e8b371c97459f84729f", null ],
    [ "h_ParamRptCount", "structT__RL__API__SENS__PER__CHIRP__CFG.html#a49443e893cf7e2008ad98d764cc4305c", null ],
    [ "w_Reserved1", "structT__RL__API__SENS__PER__CHIRP__CFG.html#a94b7e367d00db535542e6e8c74eeb78a", null ]
];