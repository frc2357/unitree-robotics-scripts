var unionU__FECCTRL__FECSS__GPADC__MEM__STATUS =
[
    [ "b1_MemInitStatus", "unionU__FECCTRL__FECSS__GPADC__MEM__STATUS.html#ac742fb0bd45b4a9408a8fa34ced4af91", null ],
    [ "b31_Padfield_0", "unionU__FECCTRL__FECSS__GPADC__MEM__STATUS.html#a6a5501d56627cdd1079325301aa09d14", null ],
    [ "b32_Reg", "unionU__FECCTRL__FECSS__GPADC__MEM__STATUS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__FECCTRL__FECSS__GPADC__MEM__STATUS.html#a42d2e3ac449ebb4b81d740f5818dd6ac", null ]
];