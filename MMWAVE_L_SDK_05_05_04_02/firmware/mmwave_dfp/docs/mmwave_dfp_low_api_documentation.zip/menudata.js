/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Related Pages",url:"pages.html"},
{text:"Modules",url:"modules.html"},
{text:"Data Structures",url:"annotated.html",children:[
{text:"Data Structures",url:"annotated.html"},
{text:"Data Structure Index",url:"classes.html"},
{text:"Data Fields",url:"functions.html",children:[
{text:"All",url:"functions.html",children:[
{text:"b",url:"functions.html#index_b"},
{text:"c",url:"functions_c.html#index_c"},
{text:"h",url:"functions_h.html#index_h"},
{text:"p",url:"functions_p.html#index_p"},
{text:"r",url:"functions_r.html#index_r"},
{text:"w",url:"functions_w.html#index_w"},
{text:"x",url:"functions_x.html#index_x"},
{text:"z",url:"functions_z.html#index_z"}]},
{text:"Variables",url:"functions_vars.html",children:[
{text:"b",url:"functions_vars.html#index_b"},
{text:"c",url:"functions_vars_c.html#index_c"},
{text:"h",url:"functions_vars_h.html#index_h"},
{text:"p",url:"functions_vars_p.html#index_p"},
{text:"r",url:"functions_vars_r.html#index_r"},
{text:"w",url:"functions_vars_w.html#index_w"},
{text:"x",url:"functions_vars_x.html#index_x"},
{text:"z",url:"functions_vars_z.html#index_z"}]}]}]},
{text:"Files",url:"files.html",children:[
{text:"File List",url:"files.html"},
{text:"Globals",url:"globals.html",children:[
{text:"All",url:"globals.html",children:[
{text:"d",url:"globals.html#index_d"},
{text:"f",url:"globals_f.html#index_f"},
{text:"m",url:"globals_m.html#index_m"},
{text:"r",url:"globals_r.html#index_r"},
{text:"s",url:"globals_s.html#index_s"},
{text:"t",url:"globals_t.html#index_t"},
{text:"u",url:"globals_u.html#index_u"},
{text:"w",url:"globals_w.html#index_w"},
{text:"z",url:"globals_z.html#index_z"}]},
{text:"Functions",url:"globals_func.html",children:[
{text:"f",url:"globals_func.html#index_f"},
{text:"r",url:"globals_func_r.html#index_r"},
{text:"s",url:"globals_func_s.html#index_s"}]},
{text:"Variables",url:"globals_vars.html"},
{text:"Typedefs",url:"globals_type.html"},
{text:"Macros",url:"globals_defs.html",children:[
{text:"f",url:"globals_defs.html#index_f"},
{text:"m",url:"globals_defs_m.html#index_m"},
{text:"r",url:"globals_defs_r.html#index_r"}]}]}]}]}
