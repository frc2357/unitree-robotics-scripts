var unionU__FECCTRL__CM3__CPU__HALT__HANDSHAKE =
[
    [ "b32_Reg", "unionU__FECCTRL__CM3__CPU__HALT__HANDSHAKE.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b32_Value", "unionU__FECCTRL__CM3__CPU__HALT__HANDSHAKE.html#a455f75cc0afd22fcfd63f1be0339b02f", null ],
    [ "bits", "unionU__FECCTRL__CM3__CPU__HALT__HANDSHAKE.html#a7f84eab21f6496a321ec4bf2def63015", null ]
];