var unionU__CT__MISC__OVERRIDE__TX__BPM =
[
    [ "b32_Reg", "unionU__CT__MISC__OVERRIDE__TX__BPM.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b32_TxBpmOverride", "unionU__CT__MISC__OVERRIDE__TX__BPM.html#a87af5ec8e70dc5dc03cc1833f24bcf63", null ],
    [ "bits", "unionU__CT__MISC__OVERRIDE__TX__BPM.html#a6e95ce76832bb55cc1844f469e459b64", null ]
];