var unionU__FECCTRL__CFG__TIMEOUT__PCR3 =
[
    [ "b32_Reg", "unionU__FECCTRL__CFG__TIMEOUT__PCR3.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b32_Timeout", "unionU__FECCTRL__CFG__TIMEOUT__PCR3.html#a80884091f0a1535fed125cf5b05c7042", null ],
    [ "bits", "unionU__FECCTRL__CFG__TIMEOUT__PCR3.html#a7deb4e32b791b58219bd0d4e489fc56d", null ]
];