var unionU__CT__PERCHIRP__PARAMETER__LEN2 =
[
    [ "b16_PerchirpAdcStartTimeLen", "unionU__CT__PERCHIRP__PARAMETER__LEN2.html#a6872c8fb80f35a8baec75ccce64237fb", null ],
    [ "b16_PerchirpIdleTimeLen", "unionU__CT__PERCHIRP__PARAMETER__LEN2.html#a6231d642e7fde429270dbc198f2563ea", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__PARAMETER__LEN2.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__PARAMETER__LEN2.html#a85b08edcff563d1b9bbb1ecebd34c9f7", null ]
];