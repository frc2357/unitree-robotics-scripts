var unionU__CT__PERCHIRP__PARAM__PACK =
[
    [ "b20_Padfield_0", "unionU__CT__PERCHIRP__PARAM__PACK.html#a13b93ed323a8631842115474a1471a78", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__PARAM__PACK.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b4_PerchirpRxEnPackSize", "unionU__CT__PERCHIRP__PARAM__PACK.html#a11c3ee4518ace0e75d5a88018994dacf", null ],
    [ "b4_PerchirpTxBpmPackSize", "unionU__CT__PERCHIRP__PARAM__PACK.html#a9fef596277d75c75bd5a70ced1df17ca", null ],
    [ "b4_PerchirpTxEnPackSize", "unionU__CT__PERCHIRP__PARAM__PACK.html#a695885f1ff77de44bafc785910251ec6", null ],
    [ "bits", "unionU__CT__PERCHIRP__PARAM__PACK.html#ac599407876a4fd4fa44690d6baddddd6", null ]
];