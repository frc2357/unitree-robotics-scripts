var unionU__CT__RAPID__EN__OVERRIDE__TX__REG =
[
    [ "b1_RapidEnPaTxallOverride", "unionU__CT__RAPID__EN__OVERRIDE__TX__REG.html#a5fa1860a118ab32823fe3ff8f125e10b", null ],
    [ "b23_Padfield_0", "unionU__CT__RAPID__EN__OVERRIDE__TX__REG.html#a0975a0ef43fcbc5f916d2aa107c9aebe", null ],
    [ "b32_Reg", "unionU__CT__RAPID__EN__OVERRIDE__TX__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_RapidEnLoTxOverride", "unionU__CT__RAPID__EN__OVERRIDE__TX__REG.html#ab60f6847d928bb145efcd272e7e50a56", null ],
    [ "bits", "unionU__CT__RAPID__EN__OVERRIDE__TX__REG.html#a2e80be57484502b4c658d9a20042bef7", null ]
];