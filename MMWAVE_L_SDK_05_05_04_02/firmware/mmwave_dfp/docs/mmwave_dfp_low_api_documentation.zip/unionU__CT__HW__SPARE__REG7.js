var unionU__CT__HW__SPARE__REG7 =
[
    [ "b32_HwSpareReg7", "unionU__CT__HW__SPARE__REG7.html#ac8b899280d19c7c9e3261db106b5e947", null ],
    [ "b32_Reg", "unionU__CT__HW__SPARE__REG7.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__HW__SPARE__REG7.html#ade03071b61fc10e5adc8b7219fd5bcf3", null ]
];