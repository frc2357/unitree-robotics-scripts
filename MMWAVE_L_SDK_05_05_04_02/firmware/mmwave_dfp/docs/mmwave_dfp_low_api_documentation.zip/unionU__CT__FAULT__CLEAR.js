var unionU__CT__FAULT__CLEAR =
[
    [ "b1_FaultClr", "unionU__CT__FAULT__CLEAR.html#a73e2e1062f73045950d683dda421b8bc", null ],
    [ "b31_Padfield_0", "unionU__CT__FAULT__CLEAR.html#a6a5501d56627cdd1079325301aa09d14", null ],
    [ "b32_Reg", "unionU__CT__FAULT__CLEAR.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__FAULT__CLEAR.html#aa9fd48c9a02f9c863af0afe37745065d", null ]
];