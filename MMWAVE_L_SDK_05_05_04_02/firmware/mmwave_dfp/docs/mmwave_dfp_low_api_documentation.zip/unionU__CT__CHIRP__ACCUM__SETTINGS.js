var unionU__CT__CHIRP__ACCUM__SETTINGS =
[
    [ "b24_Padfield_0", "unionU__CT__CHIRP__ACCUM__SETTINGS.html#a5eee3a45ed8ea134718d5c80b151fa5c", null ],
    [ "b32_Reg", "unionU__CT__CHIRP__ACCUM__SETTINGS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_NumChirpAccum", "unionU__CT__CHIRP__ACCUM__SETTINGS.html#a35219e1d321bc654e1517ddd7ad2e4c7", null ],
    [ "bits", "unionU__CT__CHIRP__ACCUM__SETTINGS.html#ac39a129b196cd7426944e742c6d2802e", null ]
];