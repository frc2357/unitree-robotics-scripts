var unionU__CT__SYNTH__FAST__RESET__TIMING__2__3__REG =
[
    [ "b32_Reg", "unionU__CT__SYNTH__FAST__RESET__TIMING__2__3__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_SynthFastResetEndTime2", "unionU__CT__SYNTH__FAST__RESET__TIMING__2__3__REG.html#a37323475f9b3d06878997ab59bb692e9", null ],
    [ "b8_SynthFastResetEndTime3", "unionU__CT__SYNTH__FAST__RESET__TIMING__2__3__REG.html#ac5610b065fe4e131617affb69218e29f", null ],
    [ "b8_SynthFastResetStartTime2", "unionU__CT__SYNTH__FAST__RESET__TIMING__2__3__REG.html#a23e5bc35cc2145086b446cd02965aeb0", null ],
    [ "b8_SynthFastResetStartTime3", "unionU__CT__SYNTH__FAST__RESET__TIMING__2__3__REG.html#a178cf68b3c6be25d1319de7f9a8e6482", null ],
    [ "bits", "unionU__CT__SYNTH__FAST__RESET__TIMING__2__3__REG.html#aed7039e8f972745c8cc472712ab8ade9", null ]
];