var structT__RL__API__MON__LIVE__SYNTH__FREQ__RESULT =
[
    [ "c_MonStatus", "structT__RL__API__MON__LIVE__SYNTH__FREQ__RESULT.html#af1807fc1b4af93b1d5776a0df30afe99", null ],
    [ "c_Reserved1", "structT__RL__API__MON__LIVE__SYNTH__FREQ__RESULT.html#ad96962542b1b0b9bbad845921adee9b0", null ],
    [ "h_Reserved2", "structT__RL__API__MON__LIVE__SYNTH__FREQ__RESULT.html#af6916cc7db5fbc2060e7cfe6bf4c12a9", null ],
    [ "w_FrameCount", "structT__RL__API__MON__LIVE__SYNTH__FREQ__RESULT.html#a4186c07ac82a66607babd235976572cd", null ],
    [ "w_FreqErrFailCount", "structT__RL__API__MON__LIVE__SYNTH__FREQ__RESULT.html#a4c88eb6be43dc7d7115e091aedba0ae3", null ],
    [ "w_Reserved3", "structT__RL__API__MON__LIVE__SYNTH__FREQ__RESULT.html#a2b7c781cf46268ffb19d3efb9c36e2ba", null ],
    [ "w_Reserved4", "structT__RL__API__MON__LIVE__SYNTH__FREQ__RESULT.html#a9fdf5cd48e45afcc69617cf33021ac93", null ],
    [ "xw_MaxSynthFreqErr", "structT__RL__API__MON__LIVE__SYNTH__FREQ__RESULT.html#a6f8e90a7cec697f33880e914292840c3", null ]
];