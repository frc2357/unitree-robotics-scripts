var unionU__CT__HW__SPARE__REG9 =
[
    [ "b32_HwSpareReg9", "unionU__CT__HW__SPARE__REG9.html#a47283c9d6913905b203cdf83cfd18935", null ],
    [ "b32_Reg", "unionU__CT__HW__SPARE__REG9.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__HW__SPARE__REG9.html#a64ec5bbb4a51159e0f8eb1d58be0c5eb", null ]
];