var unionU__CT__NUM__CHIRPS__AND__BURSTS =
[
    [ "b16_NumBurstsPerFrame", "unionU__CT__NUM__CHIRPS__AND__BURSTS.html#a6e6472a11bbc4a7c0aac2062321e5896", null ],
    [ "b16_NumChirpsPerBurst", "unionU__CT__NUM__CHIRPS__AND__BURSTS.html#a54410ea4f7196bb21693295e3bfa863e", null ],
    [ "b32_Reg", "unionU__CT__NUM__CHIRPS__AND__BURSTS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__NUM__CHIRPS__AND__BURSTS.html#af61e76e453a583368c4eddd8de3a5917", null ]
];