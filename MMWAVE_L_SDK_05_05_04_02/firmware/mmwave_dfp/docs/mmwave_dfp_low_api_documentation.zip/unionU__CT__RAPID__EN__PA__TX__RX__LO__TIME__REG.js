var unionU__CT__RAPID__EN__PA__TX__RX__LO__TIME__REG =
[
    [ "b32_Reg", "unionU__CT__RAPID__EN__PA__TX__RX__LO__TIME__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_Padfield_0", "unionU__CT__RAPID__EN__PA__TX__RX__LO__TIME__REG.html#a69b308cc2c42c40c7788924b4aae5c55", null ],
    [ "b8_RapidEnLoRxallEndTime", "unionU__CT__RAPID__EN__PA__TX__RX__LO__TIME__REG.html#a7ca06394c0c757b9c8000d7961074465", null ],
    [ "b8_RapidEnLoRxallStartTime", "unionU__CT__RAPID__EN__PA__TX__RX__LO__TIME__REG.html#ae6a82a795392aa6ae821781f672ca0fc", null ],
    [ "b8_RapidEnPaTxallEndTime", "unionU__CT__RAPID__EN__PA__TX__RX__LO__TIME__REG.html#a63c9e268dd0b5b96eaf0d03ac77d15bd", null ],
    [ "bits", "unionU__CT__RAPID__EN__PA__TX__RX__LO__TIME__REG.html#a920efceae719588c9c3f4f58a56ff49d", null ]
];