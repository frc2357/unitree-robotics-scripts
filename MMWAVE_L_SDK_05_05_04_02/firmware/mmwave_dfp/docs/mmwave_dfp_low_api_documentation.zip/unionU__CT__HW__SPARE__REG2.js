var unionU__CT__HW__SPARE__REG2 =
[
    [ "b32_HwSpareReg2", "unionU__CT__HW__SPARE__REG2.html#a8417c28f63fc849d76bfef637d75be13", null ],
    [ "b32_Reg", "unionU__CT__HW__SPARE__REG2.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__HW__SPARE__REG2.html#ad05e2a5350ee3054f42801baf1a9b374", null ]
];