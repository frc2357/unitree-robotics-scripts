var unionU__CT__MISCELLENIOUS__SETTINGS =
[
    [ "b1_DisableSynthFastReset1", "unionU__CT__MISCELLENIOUS__SETTINGS.html#a0e663a4bdeb83332bdb73c5ec9490c2a", null ],
    [ "b1_DisableSynthFastReset2", "unionU__CT__MISCELLENIOUS__SETTINGS.html#a9653b2e6647462e0430fca40024f27ce", null ],
    [ "b1_DisableSynthFastReset3", "unionU__CT__MISCELLENIOUS__SETTINGS.html#ad82273c6ebca7217708413e0eb884b06", null ],
    [ "b1_HpfFastInitEn", "unionU__CT__MISCELLENIOUS__SETTINGS.html#ab10fd8444be8d00c6cc5dad0e7c2fa83", null ],
    [ "b28_Padfield_0", "unionU__CT__MISCELLENIOUS__SETTINGS.html#a695ce030f1b67b139d277466993c83a0", null ],
    [ "b32_Reg", "unionU__CT__MISCELLENIOUS__SETTINGS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__MISCELLENIOUS__SETTINGS.html#ae921db5645cff3eeab4487db8d0beacf", null ]
];