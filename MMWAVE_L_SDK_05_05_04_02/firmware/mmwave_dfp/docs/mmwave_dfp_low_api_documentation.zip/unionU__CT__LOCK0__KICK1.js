var unionU__CT__LOCK0__KICK1 =
[
    [ "b32_Reg", "unionU__CT__LOCK0__KICK1.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b32_Value", "unionU__CT__LOCK0__KICK1.html#a455f75cc0afd22fcfd63f1be0339b02f", null ],
    [ "bits", "unionU__CT__LOCK0__KICK1.html#a6699bcdb72acc76ca05cabe93423a8ee", null ]
];