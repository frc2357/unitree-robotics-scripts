var unionU__CT__TX__START__TIME =
[
    [ "b16_Padfield_0", "unionU__CT__TX__START__TIME.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b16_TxStartTime", "unionU__CT__TX__START__TIME.html#ac92b24523bf0d12445ad237399630d46", null ],
    [ "b32_Reg", "unionU__CT__TX__START__TIME.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__TX__START__TIME.html#a7b93c2b54a80951d5220daffbbca9cba", null ]
];