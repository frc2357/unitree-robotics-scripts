var unionU__CT__RAPID__EN__BB__RX__END__TIME__REG =
[
    [ "b32_Reg", "unionU__CT__RAPID__EN__BB__RX__END__TIME__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_RapidEnBbRx1EndTime", "unionU__CT__RAPID__EN__BB__RX__END__TIME__REG.html#af457e0f99906b7512c61c2654bec0a8d", null ],
    [ "b8_RapidEnBbRx2EndTime", "unionU__CT__RAPID__EN__BB__RX__END__TIME__REG.html#a1aad8f3f63af5a7a45b8d3f42839e163", null ],
    [ "b8_RapidEnBbRx3EndTime", "unionU__CT__RAPID__EN__BB__RX__END__TIME__REG.html#a90d7003dcb49413595fc55effec41b03", null ],
    [ "b8_RapidEnBbRx4EndTime", "unionU__CT__RAPID__EN__BB__RX__END__TIME__REG.html#a02aead1e55de21c16babd11b78ef32c7", null ],
    [ "bits", "unionU__CT__RAPID__EN__BB__RX__END__TIME__REG.html#a277ce39c3438fd89a437a8817da2dd63", null ]
];