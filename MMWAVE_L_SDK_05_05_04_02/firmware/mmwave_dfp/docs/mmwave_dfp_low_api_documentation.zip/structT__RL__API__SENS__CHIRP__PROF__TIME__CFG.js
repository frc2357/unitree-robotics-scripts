var structT__RL__API__SENS__CHIRP__PROF__TIME__CFG =
[
    [ "h_ChirpAdcStartTime", "structT__RL__API__SENS__CHIRP__PROF__TIME__CFG.html#a2f93fb5dcfbac4d16fe50ecd986a1bc5", null ],
    [ "h_ChirpIdleTime", "structT__RL__API__SENS__CHIRP__PROF__TIME__CFG.html#a895226ed839d9e10f0ccaf538d878420", null ],
    [ "h_ChirpTxBpmEnSel", "structT__RL__API__SENS__CHIRP__PROF__TIME__CFG.html#adf05a09c94ed30741af3a11e499d9dac", null ],
    [ "h_ChirpTxEnSel", "structT__RL__API__SENS__CHIRP__PROF__TIME__CFG.html#ae40cbcd361564d7f0331de1c274c6261", null ],
    [ "w_ChirpRfFreqStart", "structT__RL__API__SENS__CHIRP__PROF__TIME__CFG.html#a82709ebcf1f3f03ecbcaa0db6d1d743b", null ],
    [ "w_Reserved1", "structT__RL__API__SENS__CHIRP__PROF__TIME__CFG.html#a94b7e367d00db535542e6e8c74eeb78a", null ],
    [ "w_Reserved2", "structT__RL__API__SENS__CHIRP__PROF__TIME__CFG.html#ac817834d2f697e60403efda4173a411e", null ],
    [ "xh_ChirpRfFreqSlope", "structT__RL__API__SENS__CHIRP__PROF__TIME__CFG.html#a282a3f822d418256c410242ea34ee551", null ],
    [ "xh_ChirpTxStartTime", "structT__RL__API__SENS__CHIRP__PROF__TIME__CFG.html#a922d1626677044a7d4153943ce86e0f1", null ]
];