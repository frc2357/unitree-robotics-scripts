var unionU__FECCTRL__FAULT__TYPE__STATUS =
[
    [ "b1_FaultNs", "unionU__FECCTRL__FAULT__TYPE__STATUS.html#aabb3d362af0ed82734afc69321a8f7a3", null ],
    [ "b25_Padfield_0", "unionU__FECCTRL__FAULT__TYPE__STATUS.html#a4054dfe3480d2d26f1996b52e7c862e7", null ],
    [ "b32_Reg", "unionU__FECCTRL__FAULT__TYPE__STATUS.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b6_FaultType", "unionU__FECCTRL__FAULT__TYPE__STATUS.html#a49db2aa896e67a3d581c00bd88ce05fa", null ],
    [ "bits", "unionU__FECCTRL__FAULT__TYPE__STATUS.html#a966eba362864daddfeb78d39f0d0a545", null ]
];