var unionU__CT__PERCHIRP__TX__BPM__REP__CNT =
[
    [ "b16_Padfield_0", "unionU__CT__PERCHIRP__TX__BPM__REP__CNT.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b16_PerchirpTxBpmRepCnt", "unionU__CT__PERCHIRP__TX__BPM__REP__CNT.html#ae302d4f9961ace7c30bbf22dbc7f03ce", null ],
    [ "b32_Reg", "unionU__CT__PERCHIRP__TX__BPM__REP__CNT.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__PERCHIRP__TX__BPM__REP__CNT.html#a45252f7fca932767c6f9364e73b9a407", null ]
];