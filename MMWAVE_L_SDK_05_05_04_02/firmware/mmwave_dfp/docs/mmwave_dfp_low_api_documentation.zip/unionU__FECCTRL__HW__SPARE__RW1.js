var unionU__FECCTRL__HW__SPARE__RW1 =
[
    [ "b32_HwSpareRw1", "unionU__FECCTRL__HW__SPARE__RW1.html#a59e80c3dd472e1c90f254f0ffb26b13f", null ],
    [ "b32_Reg", "unionU__FECCTRL__HW__SPARE__RW1.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__FECCTRL__HW__SPARE__RW1.html#a05d2223cd5868326f839e122b821adf6", null ]
];