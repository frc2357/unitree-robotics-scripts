var unionU__CT__BURST__CNT =
[
    [ "b32_BurstCnt", "unionU__CT__BURST__CNT.html#a9bfa3edcd5c886510dca8e7d33ace3ba", null ],
    [ "b32_Reg", "unionU__CT__BURST__CNT.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__BURST__CNT.html#ab9f148795784ab682708308bbde36505", null ]
];