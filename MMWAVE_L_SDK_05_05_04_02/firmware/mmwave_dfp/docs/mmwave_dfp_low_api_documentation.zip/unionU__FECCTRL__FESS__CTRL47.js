var unionU__FECCTRL__FESS__CTRL47 =
[
    [ "b15_Padfield_1", "unionU__FECCTRL__FESS__CTRL47.html#a74c03240291ab3206cc77b8ef5f797b0", null ],
    [ "b16_Padfield_0", "unionU__FECCTRL__FESS__CTRL47.html#affe794b72d4acca95d3ef1065c8c523c", null ],
    [ "b1_FessCtrl47", "unionU__FECCTRL__FESS__CTRL47.html#a5ce02c71c243e3a2528b99b13ceb1dab", null ],
    [ "b32_Reg", "unionU__FECCTRL__FESS__CTRL47.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__FECCTRL__FESS__CTRL47.html#a2d2b611b256c823f40913e00ceba49e5", null ]
];