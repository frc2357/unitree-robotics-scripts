var unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__1 =
[
    [ "b1_CrdDitherEn", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__1.html#ae520af34de9aa3df86ece874f23decb3", null ],
    [ "b1_CrdEn", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__1.html#aa800e976a1b018933ae704d654c332eb", null ],
    [ "b1_CrdLfsrLoadEn", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__1.html#ad18e21425565e2f5d90a4e2e9f8cb092", null ],
    [ "b24_CrdLfsrSeed", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__1.html#a78e9e6988cf35d1af93264a74e41465e", null ],
    [ "b32_Reg", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__1.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b5_Padfield_0", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__1.html#a1501bd3baae42be947868e95a7573e74", null ],
    [ "bits", "unionU__CT__CONTROLLED__RAMP__DOWN__SETTINGS__1.html#a315bf6a90e514d21df06ea0c01142ed2", null ]
];