var unionU__CT__HW__SPARE__REG0 =
[
    [ "b32_HwSpareReg0", "unionU__CT__HW__SPARE__REG0.html#a00b3e70148dc547dc3a34d1149d3f674", null ],
    [ "b32_Reg", "unionU__CT__HW__SPARE__REG0.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "bits", "unionU__CT__HW__SPARE__REG0.html#a00ce33f8efba896d4996140cb1337e67", null ]
];