var unionU__CT__RAPID__EN__RF__RX__START__TIME__REG =
[
    [ "b32_Reg", "unionU__CT__RAPID__EN__RF__RX__START__TIME__REG.html#a8cb9bb58bf7e7e996d381e67d23759ca", null ],
    [ "b8_RapidEnRfRx1StartTime", "unionU__CT__RAPID__EN__RF__RX__START__TIME__REG.html#ab22c59dfcab722877c7bfb0ef0eddbee", null ],
    [ "b8_RapidEnRfRx2StartTime", "unionU__CT__RAPID__EN__RF__RX__START__TIME__REG.html#a785a41d28f3e8f9c807b6e61c4beac33", null ],
    [ "b8_RapidEnRfRx3StartTime", "unionU__CT__RAPID__EN__RF__RX__START__TIME__REG.html#a7b59a07a389e387965f859c786e82087", null ],
    [ "b8_RapidEnRfRx4StartTime", "unionU__CT__RAPID__EN__RF__RX__START__TIME__REG.html#a77d3b319fc54aaada5d72e923753eeee", null ],
    [ "bits", "unionU__CT__RAPID__EN__RF__RX__START__TIME__REG.html#a6f0c35c61764c53e0d388791e222a2fa", null ]
];